export interface GRDocument {
  id: string;
  refNo: string;
  title: string;
  department: string;
  policyCategory: string;
  priority: 'Standard' | 'Urgent' | 'Critical';
  language: 'Marathi' | 'English';
  generatedDate: string;
  status: 'Draft' | 'Reviewing' | 'Approved' | 'Conflict';
  preamble: string;
  financialProvisions: string;
  technicalSpecs: string;
  implementationBody: string;
  complianceRisk?: string;
  signatory: string;
  signatoryTitle: string;
  officerNotes?: string;
  complianceScore: number;
  formattingStatus: string;
  references: string[];
  copiesTo: string[];
  supportingDocs?: string[];
  aiRecommendation?: string;
}

export interface NotificationItem {
  id: string;
  type: 'policy' | 'conflict' | 'system';
  title: string;
  description: string;
  timestamp: string;
  read: boolean;
  grRef?: string;
}

export interface RetrievedGR {
  grNumber: string;
  title: string;
  department: string;
  date: string;
  relevantClause: string;
  relevanceScore: number;
  category: string;
}

export interface ConflictRecord {
  id: string;
  conflictType:
    | 'Budget mismatch'
    | 'Department ownership mismatch'
    | 'Eligibility mismatch'
    | 'Timeline mismatch'
    | 'Superseded GR'
    | 'Conflicting legal clause'
    | 'Duplicate implementation authority'
    | 'Different beneficiary definitions'
    | 'Contradictory financial allocation'
    | 'Different execution agency';
  oldGRNumber: string;
  newGRNumber: string;
  oldStatement: string;
  newStatement: string;
  reasonForContradiction: string;
  sourceReferences: {
    oldDept: string;
    newDept: string;
    oldGRTitle: string;
    date: string;
  };
  selectedOption?: 'OLD' | 'NEW' | 'CUSTOM';
  customStatementText?: string;
  status: 'Pending' | 'Resolved';
  // Optional compatibility fields
  sourceGR?: string;
  sourceGRNumber?: string;
  sourceDept?: string;
  targetGR?: string;
  targetDept?: string;
  date?: string;
  severity?: 'High' | 'Medium' | 'Low';
  description?: string;
  existingClause?: string;
  conflictingClause?: string;
  clauseOverlap?: string;
  aiExplanation?: string;
  aiFixSuggestion?: string;
  recommendationOptions?: string[];
  confidenceScore?: number;
}

export interface ValidationSession {
  activeDraft: GRDocument | null;
  retrievedGRs: RetrievedGR[];
  conflicts: ConflictRecord[];
  iteration: number;
  isLoopComplete: boolean;
  resolvedHistory: {
    iteration: number;
    conflictId: string;
    resolutionText: string;
  }[];
}

export type NavView = 
  | 'dashboard'
  | 'create'
  | 'review'
  | 'preview'
  | 'conflicts'
  | 'documents'
  | 'history'
  | 'analytics'
  | 'settings'
  | 'profile';
