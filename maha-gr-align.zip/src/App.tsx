import React, { useState } from 'react';
import {
  GRDocument,
  NavView,
  NotificationItem,
  ValidationSession,
  RetrievedGR,
} from './types';
import {
  INITIAL_GR_DOCUMENTS,
  INITIAL_NOTIFICATIONS,
  INITIAL_CONFLICTS,
} from './data';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Footer } from './components/Footer';
import { LoginPage } from './components/LoginPage';
import { DashboardView } from './components/DashboardView';
import { CreateGRView } from './components/CreateGRView';
import { AIDraftReviewView } from './components/AIDraftReviewView';
import { OfficialDocumentPreviewView } from './components/OfficialDocumentPreviewView';
import { ConflictDetectionView } from './components/ConflictDetectionView';
import { GeneratedDocumentsView } from './components/GeneratedDocumentsView';
import { AnalyticsView } from './components/AnalyticsView';
import { SettingsView } from './components/SettingsView';
import { OfficerProfileView } from './components/OfficerProfileView';

const INITIAL_RETRIEVED_GRS: RetrievedGR[] = [
  {
    grNumber: 'GR No. 2023/FIN-88',
    title: 'Mandatory Quarterly Tranche Disbursement Guidelines for Capital Outlays',
    department: 'Finance Department',
    date: '12/05/2023',
    relevantClause: 'Clause 4.1: Capital grants exceeding ₹100 Crores shall strictly be released in four equal quarterly installments subject to QPR submission.',
    relevanceScore: 98,
    category: 'Financial Allocation'
  },
  {
    grNumber: 'GR No. 2023/AGRI-45',
    title: 'Agrarian Emergency Relief Disbursement Rules',
    department: 'Agriculture Department',
    date: '18/08/2023',
    relevantClause: 'Clause 4: All emergency agricultural relief grants must be disbursed exclusively by District Agriculture Officers under Department approval.',
    relevanceScore: 95,
    category: 'Public Policy'
  },
  {
    grNumber: 'GR No. 2022/ULB-12',
    title: 'Urban Local Body Cost-Sharing Framework',
    department: 'Urban Development',
    date: '14/11/2022',
    relevantClause: 'Clause 12: Standard state-to-ULB funding share for Tier-II city infrastructure projects is fixed at 60:40.',
    relevanceScore: 91,
    category: 'Infrastructure'
  },
  {
    grNumber: 'GR No. 2024/GAD-101',
    title: 'Inter-Departmental Nodal Agency & Authority Rules',
    department: 'General Administration Department',
    date: '10/01/2024',
    relevantClause: 'Clause 3: Cross-departmental initiatives exceeding ₹200 Cr require joint co-signing by Principal Secretary GAD and IT Nodal Officer.',
    relevanceScore: 89,
    category: 'Governance'
  }
];

export function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentView, setCurrentView] = useState<NavView>('dashboard');
  const [documents, setDocuments] = useState<GRDocument[]>(INITIAL_GR_DOCUMENTS);
  const [selectedDoc, setSelectedDoc] = useState<GRDocument>(INITIAL_GR_DOCUMENTS[0]);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [searchQuery, setSearchQuery] = useState('');
  const [showNotifDrawer, setShowNotifDrawer] = useState(false);

  // Global Validation Session State for Conflict Detection Loop
  const [validationSession, setValidationSession] = useState<ValidationSession>({
    activeDraft: INITIAL_GR_DOCUMENTS[0],
    retrievedGRs: INITIAL_RETRIEVED_GRS,
    conflicts: INITIAL_CONFLICTS,
    iteration: 1,
    isLoopComplete: false,
    resolvedHistory: []
  });

  const handleLogin = (_email: string) => {
    setIsAuthenticated(true);
    setCurrentView('dashboard');
  };

  const handleAddNewDoc = (newDoc: GRDocument) => {
    setDocuments((prev) => [newDoc, ...prev]);
    setSelectedDoc(newDoc);
  };

  const handleUpdateSelectedDoc = (updatedDoc: GRDocument) => {
    setSelectedDoc(updatedDoc);
    setDocuments((prev) =>
      prev.map((d) => (d.id === updatedDoc.id ? updatedDoc : d))
    );
  };

  const handleMarkAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-[#e7e8e9] text-[#191c1d] flex flex-col font-sans selection:bg-[#004485] selection:text-white">
      {/* Top Header */}
      <Header
        currentView={currentView}
        setCurrentView={setCurrentView}
        notifications={notifications}
        setNotifications={setNotifications}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onOpenNotifications={() => setShowNotifDrawer(true)}
      />

      <div className="flex flex-1 relative">
        {/* Left Navigation Sidebar */}
        <Sidebar currentView={currentView} setCurrentView={setCurrentView} />

        {/* Main Content Viewport */}
        <main className="flex-1 md:ml-64 p-4 md:p-8 flex flex-col min-w-0 overflow-x-hidden">
          {currentView === 'dashboard' && (
            <DashboardView
              documents={documents}
              notifications={notifications}
              setCurrentView={setCurrentView}
              setSelectedDoc={setSelectedDoc}
              onMarkAllNotificationsRead={handleMarkAllNotificationsRead}
            />
          )}

          {currentView === 'create' && (
            <CreateGRView
              onGenerate={handleAddNewDoc}
              setValidationSession={setValidationSession}
              setCurrentView={setCurrentView}
            />
          )}

          {currentView === 'review' && (
            <AIDraftReviewView
              doc={selectedDoc}
              setDoc={handleUpdateSelectedDoc}
              setCurrentView={setCurrentView}
            />
          )}

          {currentView === 'preview' && (
            <OfficialDocumentPreviewView
              doc={selectedDoc}
              setCurrentView={setCurrentView}
            />
          )}

          {currentView === 'conflicts' && (
            <ConflictDetectionView
              validationSession={validationSession}
              setValidationSession={setValidationSession}
              setCurrentView={setCurrentView}
              setSelectedDoc={setSelectedDoc}
              onFinalizeGR={handleUpdateSelectedDoc}
            />
          )}

          {(currentView === 'documents' || currentView === 'history') && (
            <GeneratedDocumentsView
              documents={documents}
              setCurrentView={setCurrentView}
              setSelectedDoc={setSelectedDoc}
            />
          )}

          {currentView === 'analytics' && <AnalyticsView />}

          {currentView === 'settings' && <SettingsView />}

          {currentView === 'profile' && <OfficerProfileView />}

          <Footer />
        </main>
      </div>

      {/* Notifications Drawer */}
      {showNotifDrawer && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/30 backdrop-blur-xs no-print">
          <div className="bg-white w-full max-w-sm h-full shadow-2xl p-6 flex flex-col justify-between border-l border-[#c2c6d3]">
            <div>
              <div className="flex justify-between items-center border-b border-[#e1e3e4] pb-4 mb-4">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-[#004485]">
                    notifications
                  </span>
                  <h3 className="font-poppins font-bold text-base text-[#191c1d]">
                    Notifications
                  </h3>
                </div>
                <button
                  onClick={() => setShowNotifDrawer(false)}
                  className="text-[#424751] hover:text-[#191c1d] cursor-pointer"
                >
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>

              <div className="space-y-3">
                {notifications.map((n) => (
                  <div
                    key={n.id}
                    className="p-3 bg-[#f3f4f5] rounded-lg border border-[#c2c6d3] text-xs hover:bg-[#e7e8e9] transition-colors cursor-pointer"
                    onClick={() => {
                      if (n.grRef) {
                        const doc = documents.find((d) => d.id === n.grRef || d.refNo.includes(n.grRef!));
                        if (doc) setSelectedDoc(doc);
                        setCurrentView('review');
                      }
                      setShowNotifDrawer(false);
                    }}
                  >
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-bold text-[#191c1d]">{n.title}</span>
                      <span className="text-[10px] text-[#727783]">{n.timestamp}</span>
                    </div>
                    <p className="text-[#424751]">{n.description}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-[#e1e3e4]">
              <button
                onClick={() => {
                  handleMarkAllNotificationsRead();
                  setShowNotifDrawer(false);
                }}
                className="w-full bg-[#004485] text-white py-2 rounded-lg font-bold text-xs hover:bg-[#0b5cad] cursor-pointer"
              >
                Mark All as Read
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
