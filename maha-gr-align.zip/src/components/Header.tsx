import React, { useState } from 'react';
import { NavView, NotificationItem } from '../types';

interface HeaderProps {
  currentView: NavView;
  setCurrentView: (view: NavView) => void;
  notifications: NotificationItem[];
  setNotifications: React.Dispatch<React.SetStateAction<NotificationItem[]>>;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onOpenNotifications: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentView,
  setCurrentView,
  notifications,
  searchQuery,
  setSearchQuery,
  onOpenNotifications,
}) => {
  const [showHelpModal, setShowHelpModal] = useState(false);
  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <header className="bg-[#e1e3e4] flex justify-between items-center px-6 py-2 w-full border-b border-[#c2c6d3] sticky top-0 z-40 no-print">
      <div className="flex items-center gap-6">
        <button
          onClick={() => setCurrentView('dashboard')}
          className="text-left flex items-center gap-2 group cursor-pointer"
        >
          <span className="font-poppins text-2xl font-bold tracking-tight text-[#004485] group-hover:text-[#0b5cad] transition-colors">
            MAHA-GR ALIGN
          </span>
        </button>

        {currentView === 'create' && (
          <div className="flex items-center gap-3">
            <div className="h-5 w-px bg-[#c2c6d3]"></div>
            <span className="text-[#424751] font-medium text-sm">Create New GR</span>
          </div>
        )}

        {(currentView === 'review' || currentView === 'preview') && (
          <nav className="hidden md:flex items-center gap-6 ml-4">
            <button
              onClick={() => setCurrentView('create')}
              className={`text-sm font-medium transition-colors ${
                currentView === 'create' ? 'text-[#004485] font-bold border-b-2 border-[#004485] pb-0.5' : 'text-[#424751] hover:text-[#004485]'
              }`}
            >
              Drafting
            </button>
            <button
              onClick={() => setCurrentView('documents')}
              className={`text-sm font-medium transition-colors ${
                currentView === 'documents' ? 'text-[#004485] font-bold border-b-2 border-[#004485] pb-0.5' : 'text-[#424751] hover:text-[#004485]'
              }`}
            >
              Library
            </button>
            <button
              onClick={() => setCurrentView('preview')}
              className={`text-sm font-medium transition-colors ${
                currentView === 'preview' || currentView === 'review'
                  ? 'text-[#004485] font-bold border-b-2 border-[#004485] pb-0.5'
                  : 'text-[#424751] hover:text-[#004485]'
              }`}
            >
              Alignment
            </button>
          </nav>
        )}
      </div>

      <div className="flex items-center gap-4">
        <div className="relative hidden sm:block">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-white border border-[#c2c6d3] rounded-lg pl-3 pr-9 py-1.5 text-xs focus:ring-2 focus:ring-[#004485] outline-none w-56 sm:w-64 transition-all"
            placeholder={
              currentView === 'create'
                ? 'Search archives...'
                : currentView === 'preview'
                ? 'Search Documents...'
                : 'Search GRs, files...'
            }
          />
          <span className="material-symbols-outlined absolute right-2.5 top-2 text-[#424751] text-lg pointer-events-none">
            search
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenNotifications}
            className="p-2 text-[#424751] hover:text-[#004485] transition-colors relative cursor-pointer"
            title="Notifications"
          >
            <span className="material-symbols-outlined text-xl">notifications</span>
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-[#ba1a1a] rounded-full ring-2 ring-white"></span>
            )}
          </button>

          <button
            onClick={() => setShowHelpModal(true)}
            className="p-2 text-[#424751] hover:text-[#004485] transition-colors cursor-pointer"
            title="Help & Support"
          >
            <span className="material-symbols-outlined text-xl">help</span>
          </button>

          <button
            onClick={() => setCurrentView('profile')}
            className="w-8 h-8 rounded-full bg-[#0b5cad] flex items-center justify-center border border-[#004485] text-white overflow-hidden hover:opacity-90 transition-opacity cursor-pointer ml-1"
            title="Officer Profile"
          >
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuBhvBQNv7-vIEGrpIu_NOhQhvrL2jKF6Y-_caNIvWuQfzfclnUsz9FdGxwa6JTAed-KW5LlpPwevbzX45NN4dNCn7HSQkgQrJeE4iNGwBWHPs-1gg5rDOXdqHksmoVq83EXlh52WQE0XWWDueAW_VDV4FkGatt75G0tVL8ivoYbje1oP4wx3C_e9tKhWPvLy2wpLwMXB9DhpMhx59pQL06moT2-T30RnM4o5T9NW25GxRMUyAsv0Nymwmyz2FgFbk-cNa9g2x2bDyU"
              alt="Officer Profile"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </button>
        </div>
      </div>

      {/* Help Modal */}
      {showHelpModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-lg w-full p-6 shadow-xl border border-[#c2c6d3]">
            <div className="flex justify-between items-center mb-4 border-b border-[#e1e3e4] pb-3">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#004485]">help</span>
                <h3 className="font-poppins font-bold text-lg text-[#191c1d]">
                  MAHA-GR ALIGN Guidance
                </h3>
              </div>
              <button
                onClick={() => setShowHelpModal(false)}
                className="text-[#424751] hover:text-[#ba1a1a] cursor-pointer"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            <div className="space-y-3 text-sm text-[#424751] leading-relaxed">
              <p>
                <strong>MAHA-GR ALIGN</strong> is the official e-Governance portal of the
                Government of Maharashtra for AI-powered semantic alignment and conflict detection.
              </p>
              <ul className="list-disc pl-5 space-y-1 text-xs">
                <li>
                  <strong>Create New GR:</strong> Fill parameters and generate AI draft resolutions with automated semantic references.
                </li>
                <li>
                  <strong>Conflict Detection:</strong> Scans draft resolutions against 142,000+ past state resolutions to highlight overlaps.
                </li>
                <li>
                  <strong>AI Draft Review:</strong> Interactive document sheet with live AI risk highlights and compliance checklists.
                </li>
              </ul>
            </div>
            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setShowHelpModal(false)}
                className="bg-[#004485] text-white px-4 py-2 rounded-lg text-xs font-bold hover:bg-[#0b5cad] cursor-pointer"
              >
                Got it
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
