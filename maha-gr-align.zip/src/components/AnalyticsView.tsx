import React from 'react';

export const AnalyticsView: React.FC = () => {
  return (
    <div className="space-y-6 max-w-7xl mx-auto w-full pb-10">
      <div className="bg-white p-6 border border-[#c2c6d3] rounded-xl shadow-2xs">
        <h1 className="font-poppins text-2xl font-bold text-[#191c1d] mb-1">
          e-Governance Resolution Analytics
        </h1>
        <p className="text-sm text-[#424751]">
          Statewide alignment indices, compliance scores, and resolution issuance velocity.
        </p>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white border border-[#c2c6d3] p-6 rounded-xl shadow-2xs">
          <p className="text-xs font-bold text-[#424751] uppercase mb-1">State Alignment Index</p>
          <p className="font-poppins text-3xl font-bold text-emerald-600">98.4%</p>
          <p className="text-xs text-[#424751] mt-2">+1.2% increase after AI rule adoption</p>
        </div>

        <div className="bg-white border border-[#c2c6d3] p-6 rounded-xl shadow-2xs">
          <p className="text-xs font-bold text-[#424751] uppercase mb-1">Avg Draft Resolution Cycle</p>
          <p className="font-poppins text-3xl font-bold text-[#004485]">2.4 Hours</p>
          <p className="text-xs text-[#424751] mt-2">Reduced from 14 days baseline</p>
        </div>

        <div className="bg-white border border-[#c2c6d3] p-6 rounded-xl shadow-2xs">
          <p className="text-xs font-bold text-[#424751] uppercase mb-1">
            Prevented Overlaps (2024)
          </p>
          <p className="font-poppins text-3xl font-bold text-[#ba1a1a]">142</p>
          <p className="text-xs text-[#424751] mt-2">Legal contradictions auto-reconciled</p>
        </div>
      </div>

      {/* Department Activity Bar Chart visual */}
      <div className="bg-white border border-[#c2c6d3] rounded-xl p-6 shadow-2xs">
        <h3 className="font-poppins font-bold text-base text-[#191c1d] mb-4">
          Resolution Output by Department (Q3/Q4 2024)
        </h3>
        <div className="space-y-3">
          {[
            { dept: 'Energy & Infrastructure', count: 420, percent: 90, color: 'bg-[#004485]' },
            { dept: 'Finance Department', count: 380, percent: 80, color: 'bg-[#0b5cad]' },
            { dept: 'Home Department', count: 310, percent: 65, color: 'bg-[#385d92]' },
            { dept: 'IT & Communication', count: 290, percent: 60, color: 'bg-emerald-600' },
            { dept: 'School Education', count: 240, percent: 50, color: 'bg-amber-600' },
          ].map((item, idx) => (
            <div key={idx} className="space-y-1">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-[#191c1d]">{item.dept}</span>
                <span className="text-[#424751]">{item.count} GRs</span>
              </div>
              <div className="w-full bg-[#e7e8e9] h-3 rounded-full overflow-hidden">
                <div
                  className={`${item.color} h-full transition-all duration-500`}
                  style={{ width: `${item.percent}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
