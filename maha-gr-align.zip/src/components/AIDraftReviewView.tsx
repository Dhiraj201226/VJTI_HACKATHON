import React, { useState } from 'react';
import { GRDocument, NavView } from '../types';

interface AIDraftReviewViewProps {
  doc: GRDocument;
  setDoc: (doc: GRDocument) => void;
  setCurrentView: (view: NavView) => void;
}

export const AIDraftReviewView: React.FC<AIDraftReviewViewProps> = ({
  doc,
  setDoc,
  setCurrentView,
}) => {
  const [isEditing, setIsEditing] = useState(false);

  // Helper for direct live document field updates
  const handleFieldChange = (field: keyof GRDocument, value: any) => {
    setDoc({
      ...doc,
      [field]: value,
    });
  };

  // Checklist items state
  const [checklist, setChecklist] = useState({
    emblem: true,
    refNumbers: true,
    hierarchy: true,
    digiSig: false,
    distribution: false,
  });

  const [downloadingFormat, setDownloadingFormat] = useState<string | null>(null);

  const handleToggleChecklist = (key: keyof typeof checklist) => {
    setChecklist((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleApproveAndIssue = () => {
    const updated = {
      ...doc,
      status: 'Approved' as const,
      complianceScore: 100,
    };
    setDoc(updated);
    setCurrentView('preview');
  };

  const handleExport = (format: string) => {
    setDownloadingFormat(format);
    setTimeout(() => {
      setDownloadingFormat(null);
      setCurrentView('preview');
    }, 800);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto w-full pb-10 font-sans">
      {/* Header Context Bar */}
      <div className="bg-white px-8 py-4 border border-[#c2c6d3] rounded-xl shadow-2xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <nav className="flex gap-2 text-[11px] font-bold text-[#424751] uppercase tracking-wider mb-1">
            <span>DOCUMENTS</span>
            <span>/</span>
            <span className="text-[#004485]">{doc.id}</span>
          </nav>
          <h1 className="font-poppins text-2xl font-bold text-[#191c1d]">
            AI Draft Editor &amp; Live Document Review
          </h1>
          <p className="text-sm text-[#424751]">
            Reviewing: <span className="font-semibold text-[#191c1d]">{doc.title}</span>
          </p>
        </div>

        <div className="flex gap-3">
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="bg-white text-[#004485] border border-[#004485] px-4 py-2 font-semibold text-xs rounded-lg hover:bg-[#f3f4f5] transition-colors flex items-center gap-2 cursor-pointer"
          >
            <span className="material-symbols-outlined text-sm">
              {isEditing ? 'done' : 'edit'}
            </span>
            {isEditing ? 'Done Editing' : 'Live Edit Clauses'}
          </button>

          <button
            onClick={() => setCurrentView('conflicts')}
            className="bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 px-4 py-2 font-bold text-xs rounded-lg transition-colors flex items-center gap-2 cursor-pointer"
          >
            <span className="material-symbols-outlined text-amber-700 text-base">gavel</span>
            Conflict Review Page
          </button>

          <button
            onClick={handleApproveAndIssue}
            className="bg-[#004485] text-white px-5 py-2 font-semibold text-xs rounded-lg hover:bg-[#0b5cad] transition-colors flex items-center gap-2 cursor-pointer shadow-2xs"
          >
            <span className="material-symbols-outlined text-sm">check_circle</span>
            Approve &amp; Issue
          </button>
        </div>
      </div>

      {/* Main Grid: Document Sheet (Left 8/12) + Sidebar Controls (Right 4/12) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Document Sheet Live Preview */}
        <div className="lg:col-span-8 bg-[#e1e3e4] p-6 rounded-xl border border-[#c2c6d3] flex justify-center">
          <div className="w-full max-w-[800px] bg-white shadow-md border border-[#c2c6d3] p-10 md:p-14 font-document-text text-[#191c1d] text-base leading-relaxed min-h-[1050px] relative">
            {/* Header / Emblem */}
            <div className="text-center mb-8">
              <img
                alt="Maharashtra State Emblem"
                className="w-16 h-16 mx-auto mb-3 object-contain"
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuChD2VusDrbX1ZbmK8fxIRwrPWj72pwpHMmsocGUP7FGTem34djWfkgAoVcT5ZD_ggmCPYdv-6oaZRsD19scCQUj8SxPNcdZeMnOEQdmGDtF2gU2P5yfyapTd3CgNu-YqF2-sdd0Mb0MSV5RpmkyLu6TIoRlgtMcZnSYMJFmsm_3NaKv04e8QsfhiJA8N41LpzPmNzzfDSO32stQ5jNvskoPcwKKwnB_A1cOS97iGZy7jEYTLGkrkq4CMzaSaY0V8Ew47dmKP7POGA"
                referrerPolicy="no-referrer"
              />
              <p className="font-bold uppercase tracking-widest text-sm">
                Government of Maharashtra
              </p>

              {isEditing ? (
                <div className="max-w-xs mx-auto mt-1">
                  <input
                    type="text"
                    value={doc.department}
                    onChange={(e) => handleFieldChange('department', e.target.value)}
                    className="w-full text-center font-bold text-[#004485] border border-[#004485] p-1 rounded text-xs font-sans"
                    placeholder="Department Name"
                  />
                </div>
              ) : (
                <p className="font-bold text-[#004485]">{doc.department}</p>
              )}
              <p className="text-xs text-[#424751] font-sans">Mantralaya, Mumbai - 400032</p>
            </div>

            {/* Reference & Date Bar */}
            <div className="mb-6 border-b border-[#191c1d] pb-2 flex justify-between text-sm font-sans">
              <p>
                Ref No:{' '}
                {isEditing ? (
                  <input
                    type="text"
                    value={doc.refNo}
                    onChange={(e) => handleFieldChange('refNo', e.target.value)}
                    className="border border-[#c2c6d3] p-1 rounded font-bold text-xs"
                  />
                ) : (
                  <span className="font-bold">{doc.refNo}</span>
                )}
              </p>
              <p>
                Date: <span className="font-bold">{doc.generatedDate}</span>
              </p>
            </div>

            {/* Document Title */}
            <div className="mb-8">
              {isEditing ? (
                <div className="space-y-1">
                  <label className="block text-xs font-bold font-sans text-[#004485]">
                    Title of Resolution:
                  </label>
                  <input
                    type="text"
                    value={doc.title}
                    onChange={(e) => handleFieldChange('title', e.target.value)}
                    className="w-full border border-[#004485] p-2 rounded text-xs font-bold text-center font-poppins"
                  />
                </div>
              ) : (
                <h2 className="text-center font-bold text-base mb-2 uppercase underline text-[#004485] font-poppins tracking-wide">
                  {doc.title}
                </h2>
              )}
            </div>

            {/* Live Editable Clauses */}
            <div className="space-y-6">
              {/* 1. Preamble */}
              <section>
                <h3 className="font-bold mb-1 font-sans text-xs uppercase tracking-wider text-[#004485]">
                  1. Preamble / Background:
                </h3>
                {isEditing ? (
                  <textarea
                    value={doc.preamble}
                    onChange={(e) => handleFieldChange('preamble', e.target.value)}
                    rows={4}
                    className="w-full border border-[#c2c6d3] p-2.5 rounded text-xs font-sans leading-relaxed focus:border-[#004485] outline-none"
                  />
                ) : (
                  <p className="indent-8 text-justify">{doc.preamble}</p>
                )}
              </section>

              {/* 2. Financial Provisions */}
              <section>
                <h3 className="font-bold mb-1 font-sans text-xs uppercase tracking-wider text-[#004485]">
                  2. Financial Provisions &amp; Outlay:
                </h3>
                {isEditing ? (
                  <textarea
                    value={doc.financialProvisions}
                    onChange={(e) => handleFieldChange('financialProvisions', e.target.value)}
                    rows={4}
                    className="w-full border border-[#c2c6d3] p-2.5 rounded text-xs font-sans leading-relaxed focus:border-[#004485] outline-none"
                  />
                ) : (
                  <>
                    <p className="indent-8 text-justify">{doc.financialProvisions}</p>
                    {doc.complianceRisk && (
                      <div className="bg-[#ffdad6]/40 border-l-4 border-[#ba1a1a] p-3.5 mt-3 rounded-r flex gap-3 my-4 font-sans">
                        <span className="material-symbols-outlined text-[#ba1a1a] text-xl shrink-0 mt-0.5">
                          warning
                        </span>
                        <div>
                          <p className="font-bold text-[#ba1a1a] text-xs uppercase font-sans tracking-wide">
                            AI HIGHLIGHT: COMPLIANCE RISK
                          </p>
                          <p className="text-xs italic text-[#191c1d] mt-0.5">
                            {doc.complianceRisk}
                          </p>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </section>

              {/* 3. Technical Specs */}
              <section>
                <h3 className="font-bold mb-1 font-sans text-xs uppercase tracking-wider text-[#004485]">
                  3. Technical Parameters &amp; Specifications:
                </h3>
                {isEditing ? (
                  <textarea
                    value={doc.technicalSpecs}
                    onChange={(e) => handleFieldChange('technicalSpecs', e.target.value)}
                    rows={3}
                    className="w-full border border-[#c2c6d3] p-2.5 rounded text-xs font-sans leading-relaxed focus:border-[#004485] outline-none"
                  />
                ) : (
                  <p className="indent-8 text-justify">{doc.technicalSpecs}</p>
                )}
              </section>

              {/* 4. Implementation Body */}
              <section>
                <h3 className="font-bold mb-1 font-sans text-xs uppercase tracking-wider text-[#004485]">
                  4. Implementation Agency &amp; Nodal Oversight:
                </h3>
                {isEditing ? (
                  <textarea
                    value={doc.implementationBody}
                    onChange={(e) => handleFieldChange('implementationBody', e.target.value)}
                    rows={3}
                    className="w-full border border-[#c2c6d3] p-2.5 rounded text-xs font-sans leading-relaxed focus:border-[#004485] outline-none"
                  />
                ) : (
                  <p className="indent-8 text-justify">{doc.implementationBody}</p>
                )}
              </section>
            </div>

            {/* Signatures */}
            <div className="mt-16 flex justify-between items-end font-sans text-xs pt-8 border-t border-[#c2c6d3]/60">
              <div className="text-center w-48 border-t border-[#191c1d] pt-2">
                <p className="font-bold">({doc.signatory})</p>
                <p className="text-[#424751]">{doc.signatoryTitle}</p>
              </div>
              <div className="text-center w-56 border-t border-[#191c1d] pt-2">
                <p className="font-bold">By Order and in the Name of</p>
                <p className="font-bold">Governor of Maharashtra</p>
              </div>
            </div>
          </div>
        </div>

        {/* Right: AI Suggestions & Control Panel */}
        <div className="lg:col-span-4 space-y-5">
          {/* Export Options */}
          <div className="bg-white border border-[#c2c6d3] rounded-xl p-5 shadow-2xs">
            <h3 className="font-poppins text-sm font-bold text-[#004485] mb-3 flex items-center gap-2">
              <span className="material-symbols-outlined text-lg">download</span>
              Export Options
            </h3>
            <div className="flex flex-col gap-2.5">
              <button
                onClick={() => handleExport('PDF')}
                disabled={downloadingFormat !== null}
                className="w-full bg-[#004485] text-white py-2.5 rounded-lg font-bold text-xs flex items-center justify-center gap-2 hover:bg-[#0b5cad] transition-opacity cursor-pointer shadow-2xs"
              >
                {downloadingFormat === 'PDF' ? (
                  <span className="material-symbols-outlined animate-spin text-sm">sync</span>
                ) : (
                  <span className="material-symbols-outlined text-base">picture_as_pdf</span>
                )}
                Download Official PDF
              </button>

              <button
                onClick={() => handleExport('DOCX')}
                disabled={downloadingFormat !== null}
                className="w-full border border-[#0f61a4] text-[#0f61a4] py-2.5 rounded-lg font-bold text-xs flex items-center justify-center gap-2 hover:bg-[#d5e3ff]/40 transition-colors cursor-pointer"
              >
                {downloadingFormat === 'DOCX' ? (
                  <span className="material-symbols-outlined animate-spin text-sm">sync</span>
                ) : (
                  <span className="material-symbols-outlined text-base">description</span>
                )}
                Download DOCX
              </button>
            </div>
          </div>

          {/* Document Status */}
          <div className="bg-white border border-[#c2c6d3] rounded-xl overflow-hidden shadow-2xs">
            <div className="bg-[#004485] text-white px-4 py-2 font-bold text-[11px] uppercase tracking-wider">
              Document Compliance Status
            </div>
            <div className="p-4 space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-medium text-[#191c1d]">Compliance Score</span>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[11px] font-bold uppercase">
                  {doc.complianceScore}% PASSED
                </span>
              </div>

              <div className="w-full bg-[#e7e8e9] h-2 rounded-full overflow-hidden">
                <div
                  className="bg-emerald-500 h-full transition-all duration-500"
                  style={{ width: `${doc.complianceScore}%` }}
                ></div>
              </div>

              <div className="flex justify-between items-center pt-1 border-t border-[#f3f4f5]">
                <span className="text-xs font-medium text-[#191c1d]">Formatting Status</span>
                <div className="flex items-center gap-1 text-emerald-600">
                  <span className="material-symbols-outlined text-sm">check_circle</span>
                  <span className="text-xs font-bold">{doc.formattingStatus}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-[#e1e3e4]">
                <button
                  onClick={() => setCurrentView('conflicts')}
                  className="w-full bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 py-2.5 rounded-lg font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  <span className="material-symbols-outlined text-amber-700 text-base">gavel</span>
                  Open Conflict Review Page
                </button>
              </div>
            </div>
          </div>

          {/* Checklist */}
          <div className="bg-white border border-[#c2c6d3] rounded-xl p-5 shadow-2xs">
            <h3 className="font-poppins text-sm font-bold text-[#191c1d] mb-3">Verification Checklist</h3>
            <div className="space-y-2.5">
              <label className="flex items-start gap-2.5 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={checklist.emblem}
                  onChange={() => handleToggleChecklist('emblem')}
                  className="mt-0.5 rounded text-[#004485] focus:ring-[#004485] h-4 w-4"
                />
                <span className={checklist.emblem ? 'text-[#191c1d]' : 'text-[#424751] opacity-60'}>
                  Official emblem attached and centered
                </span>
              </label>

              <label className="flex items-start gap-2.5 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={checklist.refNumbers}
                  onChange={() => handleToggleChecklist('refNumbers')}
                  className="mt-0.5 rounded text-[#004485] focus:ring-[#004485] h-4 w-4"
                />
                <span className={checklist.refNumbers ? 'text-[#191c1d]' : 'text-[#424751] opacity-60'}>
                  Reference numbers cross-verified
                </span>
              </label>

              <label className="flex items-start gap-2.5 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={checklist.hierarchy}
                  onChange={() => handleToggleChecklist('hierarchy')}
                  className="mt-0.5 rounded text-[#004485] focus:ring-[#004485] h-4 w-4"
                />
                <span className={checklist.hierarchy ? 'text-[#191c1d]' : 'text-[#424751] opacity-60'}>
                  Departmental hierarchy verified
                </span>
              </label>

              <label className="flex items-start gap-2.5 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={checklist.digiSig}
                  onChange={() => handleToggleChecklist('digiSig')}
                  className="mt-0.5 rounded text-[#004485] focus:ring-[#004485] h-4 w-4"
                />
                <span className={checklist.digiSig ? 'text-[#191c1d]' : 'text-[#424751] opacity-60'}>
                  Digital signature token active
                </span>
              </label>

              <label className="flex items-start gap-2.5 cursor-pointer text-xs">
                <input
                  type="checkbox"
                  checked={checklist.distribution}
                  onChange={() => handleToggleChecklist('distribution')}
                  className="mt-0.5 rounded text-[#004485] focus:ring-[#004485] h-4 w-4"
                />
                <span className={checklist.distribution ? 'text-[#191c1d]' : 'text-[#424751] opacity-60'}>
                  Copy list (distribution) finalized
                </span>
              </label>
            </div>
          </div>

          {/* AI Recommendation Card */}
          <div className="bg-[#77b4fd]/20 border border-[#77b4fd] rounded-xl p-4 flex gap-3 shadow-2xs">
            <span className="material-symbols-outlined text-[#0f61a4] text-xl shrink-0">
              psychology
            </span>
            <div className="text-xs">
              <span className="font-bold text-[#00457a] block mb-1">AI Recommendation</span>
              <p className="text-[#191c1d] leading-snug">
                {doc.aiRecommendation ||
                  'Clause 2 uses a restrictive adjective. To match standard state protocols, consider using "shall" instead of "must" for inter-departmental mandates.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
