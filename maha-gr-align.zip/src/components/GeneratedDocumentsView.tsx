import React, { useState } from 'react';
import { GRDocument, NavView } from '../types';

interface GeneratedDocumentsViewProps {
  documents: GRDocument[];
  setCurrentView: (view: NavView) => void;
  setSelectedDoc: (doc: GRDocument) => void;
}

export const GeneratedDocumentsView: React.FC<GeneratedDocumentsViewProps> = ({
  documents,
  setCurrentView,
  setSelectedDoc,
}) => {
  const [filterDept, setFilterDept] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');
  const [search, setSearch] = useState('');

  const filteredDocs = documents.filter((doc) => {
    const matchesDept = filterDept === 'All' || doc.department.includes(filterDept);
    const matchesStatus = filterStatus === 'All' || doc.status === filterStatus;
    const matchesSearch =
      search === '' ||
      doc.title.toLowerCase().includes(search.toLowerCase()) ||
      doc.refNo.toLowerCase().includes(search.toLowerCase()) ||
      doc.department.toLowerCase().includes(search.toLowerCase());

    return matchesDept && matchesStatus && matchesSearch;
  });

  const handleOpenDoc = (doc: GRDocument, view: 'review' | 'preview') => {
    setSelectedDoc(doc);
    setCurrentView(view);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto w-full pb-10">
      {/* Header */}
      <div className="bg-white p-6 border border-[#c2c6d3] rounded-xl shadow-2xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="font-poppins text-2xl font-bold text-[#191c1d]">
            Generated Documents Archive
          </h1>
          <p className="text-sm text-[#424751]">
            Official state repository of published and drafted Government Resolutions.
          </p>
        </div>
        <button
          onClick={() => setCurrentView('create')}
          className="bg-[#004485] text-white px-5 py-2.5 rounded-lg font-bold text-xs flex items-center gap-2 hover:bg-[#0b5cad] cursor-pointer shadow-2xs"
        >
          <span className="material-symbols-outlined text-sm">add</span>
          Create New GR
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-4 border border-[#c2c6d3] rounded-xl shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by title, ref no..."
              className="border border-[#c2c6d3] rounded-lg pl-3 pr-8 py-1.5 text-xs outline-none focus:border-[#004485] w-56"
            />
            <span className="material-symbols-outlined absolute right-2 top-2 text-[#424751] text-base">
              search
            </span>
          </div>

          <select
            value={filterDept}
            onChange={(e) => setFilterDept(e.target.value)}
            className="border border-[#c2c6d3] rounded-lg p-1.5 text-xs bg-white text-[#191c1d] outline-none"
          >
            <option value="All">All Departments</option>
            <option value="IT & Communication">IT &amp; Communication</option>
            <option value="School Education">School Education</option>
            <option value="Finance Department">Finance Department</option>
            <option value="Energy & Infrastructure">Energy &amp; Infrastructure</option>
            <option value="Home Department">Home Department</option>
            <option value="Law & Judiciary">Law &amp; Judiciary</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="border border-[#c2c6d3] rounded-lg p-1.5 text-xs bg-white text-[#191c1d] outline-none"
          >
            <option value="All">All Statuses</option>
            <option value="Approved">Approved</option>
            <option value="Reviewing">Reviewing</option>
            <option value="Draft">Draft</option>
            <option value="Conflict">Conflict</option>
          </select>
        </div>

        <div className="text-xs text-[#424751] font-semibold">
          Showing {filteredDocs.length} of {documents.length} Records
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-[#c2c6d3] rounded-xl overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-[#001b3c] text-white text-[11px] font-bold uppercase tracking-wider">
              <tr>
                <th className="px-6 py-3.5">Ref No &amp; Title</th>
                <th className="px-6 py-3.5">Department</th>
                <th className="px-6 py-3.5">Date</th>
                <th className="px-6 py-3.5">Status</th>
                <th className="px-6 py-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="text-xs divide-y divide-[#c2c6d3]">
              {filteredDocs.map((doc, idx) => (
                <tr
                  key={doc.id}
                  className={`${
                    idx % 2 === 1 ? 'bg-[#f3f4f5]' : 'bg-white'
                  } hover:bg-[#e7e8e9] transition-colors`}
                >
                  <td className="px-6 py-4">
                    <p className="font-bold text-[#004485]">{doc.refNo}</p>
                    <p className="text-[#191c1d] font-medium line-clamp-1 mt-0.5">{doc.title}</p>
                  </td>
                  <td className="px-6 py-4 text-[#424751]">{doc.department}</td>
                  <td className="px-6 py-4 text-[#424751] whitespace-nowrap">
                    {doc.generatedDate}
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase ${
                        doc.status === 'Approved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : doc.status === 'Conflict'
                          ? 'bg-[#ffdad6] text-[#ba1a1a]'
                          : doc.status === 'Reviewing'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-[#d5e3ff] text-[#004485]'
                      }`}
                    >
                      {doc.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right space-x-2 whitespace-nowrap">
                    <button
                      onClick={() => handleOpenDoc(doc, 'review')}
                      className="bg-white border border-[#004485] text-[#004485] px-3 py-1 rounded text-xs font-bold hover:bg-[#d5e3ff]/30 cursor-pointer"
                    >
                      Review
                    </button>
                    <button
                      onClick={() => handleOpenDoc(doc, 'preview')}
                      className="bg-[#004485] text-white px-3 py-1 rounded text-xs font-bold hover:bg-[#0b5cad] cursor-pointer"
                    >
                      View Sheet
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
