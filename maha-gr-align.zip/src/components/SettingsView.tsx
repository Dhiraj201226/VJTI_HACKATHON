import React from 'react';

export const SettingsView: React.FC = () => {
  return (
    <div className="space-y-6 max-w-4xl mx-auto w-full pb-10">
      <div className="bg-white p-6 border border-[#c2c6d3] rounded-xl shadow-2xs">
        <h1 className="font-poppins text-2xl font-bold text-[#191c1d] mb-1">
          System &amp; Governance Settings
        </h1>
        <p className="text-sm text-[#424751]">
          Configure AI drafting strictness, departmental rules, and security tokens.
        </p>
      </div>

      <div className="bg-white border border-[#c2c6d3] rounded-xl p-6 space-y-6 shadow-2xs">
        <div>
          <h3 className="font-poppins font-bold text-sm text-[#004485] mb-3">
            AI Semantic Engine Parameters
          </h3>
          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between p-3 bg-[#f3f4f5] rounded border border-[#c2c6d3]">
              <div>
                <p className="font-bold text-[#191c1d]">Strict State Regulation Matching</p>
                <p className="text-[#424751]">Require 100% compliance with Treasury Rules before issuing.</p>
              </div>
              <input type="checkbox" defaultChecked className="h-5 w-5 text-[#004485]" />
            </div>

            <div className="flex items-center justify-between p-3 bg-[#f3f4f5] rounded border border-[#c2c6d3]">
              <div>
                <p className="font-bold text-[#191c1d]">Auto Marathi Translation Layer</p>
                <p className="text-[#424751]">Generate parallel bilingual drafts for all resolutions.</p>
              </div>
              <input type="checkbox" defaultChecked className="h-5 w-5 text-[#004485]" />
            </div>
          </div>
        </div>

        <div className="border-t border-[#e1e3e4] pt-4">
          <h3 className="font-poppins font-bold text-sm text-[#004485] mb-3">
            Digital Signature Token (e-Sign)
          </h3>
          <p className="text-xs text-[#424751] mb-3">
            Connected Hardware Token: <span className="font-mono font-bold text-[#191c1d]">MAHA-SEC-TOKEN-8821</span>
          </p>
          <button className="bg-[#004485] text-white px-4 py-2 rounded text-xs font-bold hover:bg-[#0b5cad] cursor-pointer">
            Re-authenticate e-Sign Token
          </button>
        </div>
      </div>
    </div>
  );
};
