import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#e1e3e4] w-full py-4 border-t border-[#c2c6d3] mt-auto no-print">
      <div className="flex flex-col md:flex-row justify-between items-center px-8 max-w-7xl mx-auto w-full gap-4">
        <div className="text-center md:text-left">
          <p className="text-xs font-bold text-[#191c1d] tracking-wider uppercase mb-0.5">
            GOVERNMENT OF MAHARASHTRA
          </p>
          <p className="text-[11px] text-[#424751]">
            © 2024. Achuk Nirnay, Pragat Maharashtra. All Rights Reserved.
          </p>
        </div>
        <div className="flex items-center gap-6">
          <a
            href="#privacy"
            onClick={(e) => e.preventDefault()}
            className="text-[11px] text-[#424751] hover:underline hover:text-[#004485] transition-colors"
          >
            Privacy Policy
          </a>
          <a
            href="#terms"
            onClick={(e) => e.preventDefault()}
            className="text-[11px] text-[#424751] hover:underline hover:text-[#004485] transition-colors"
          >
            Terms of Service
          </a>
          <a
            href="#rti"
            onClick={(e) => e.preventDefault()}
            className="text-[11px] text-[#424751] hover:underline hover:text-[#004485] transition-colors"
          >
            RTI
          </a>
          <a
            href="#contact"
            onClick={(e) => e.preventDefault()}
            className="text-[11px] text-[#424751] hover:underline hover:text-[#004485] transition-colors"
          >
            Contact Us
          </a>
        </div>
      </div>
    </footer>
  );
};
