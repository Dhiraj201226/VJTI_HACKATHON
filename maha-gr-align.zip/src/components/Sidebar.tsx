import React from 'react';
import { NavView } from '../types';

interface SidebarProps {
  currentView: NavView;
  setCurrentView: (view: NavView) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView }) => {
  const navItems = [
    { id: 'dashboard' as NavView, label: 'Dashboard', icon: 'dashboard' },
    { id: 'create' as NavView, label: 'Create New GR', icon: 'add_circle' },
    { id: 'conflicts' as NavView, label: 'Conflict Detection', icon: 'rule' },
    { id: 'review' as NavView, label: 'AI Draft Review', icon: 'psychology' },
    { id: 'documents' as NavView, label: 'Generated Documents', icon: 'description' },
    { id: 'history' as NavView, label: 'Version History', icon: 'history' },
    { id: 'analytics' as NavView, label: 'Analytics', icon: 'analytics' },
  ];

  return (
    <aside className="hidden md:flex h-screen w-64 fixed left-0 top-0 bg-[#f3f4f5] border-r border-[#c2c6d3] flex-col py-4 z-50 no-print">
      {/* Sidebar Header with Emblem */}
      <div className="px-6 mb-4">
        <div className="flex justify-center mb-3">
          <img
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuChD2VusDrbX1ZbmK8fxIRwrPWj72pwpHMmsocGUP7FGTem34djWfkgAoVcT5ZD_ggmCPYdv-6oaZRsD19scCQUj8SxPNcdZeMnOEQdmGDtF2gU2P5yfyapTd3CgNu-YqF2-sdd0Mb0MSV5RpmkyLu6TIoRlgtMcZnSYMJFmsm_3NaKv04e8QsfhiJA8N41LpzPmNzzfDSO32stQ5jNvskoPcwKKwnB_A1cOS97iGZy7jEYTLGkrkq4CMzaSaY0V8Ew47dmKP7POGA"
            alt="Maharashtra State Emblem"
            className="w-20 h-20 object-contain drop-shadow-xs"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="flex items-center gap-3 text-center justify-center">
          <div>
            <h2 className="font-poppins text-sm font-bold text-[#191c1d] leading-tight">
              Government of Maharashtra
            </h2>
            <p className="text-[11px] text-[#424751] font-medium">e-Governance Cell</p>
          </div>
        </div>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 sidebar-scroll overflow-y-auto px-2 space-y-1">
        {navItems.map((item) => {
          const isActive = currentView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-left text-xs transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#0b5cad] text-white font-semibold shadow-xs border-r-4 border-[#004485]'
                  : 'text-[#424751] hover:bg-[#e7e8e9] hover:text-[#191c1d]'
              }`}
            >
              <span className={`material-symbols-outlined text-lg ${isActive ? 'text-white' : ''}`}>
                {item.icon}
              </span>
              <span>{item.label}</span>
            </button>
          );
        })}

        <div className="pt-2 border-t border-[#c2c6d3] mt-3">
          <button
            onClick={() => setCurrentView('settings')}
            className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-left text-xs transition-all cursor-pointer ${
              currentView === 'settings'
                ? 'bg-[#0b5cad] text-white font-semibold border-r-4 border-[#004485]'
                : 'text-[#424751] hover:bg-[#e7e8e9]'
            }`}
          >
            <span className="material-symbols-outlined text-lg">settings</span>
            <span>Settings</span>
          </button>
        </div>
      </nav>

      {/* Officer Footer */}
      <div className="px-4 pt-3 border-t border-[#c2c6d3] mt-auto">
        <button
          onClick={() => setCurrentView('profile')}
          className="w-full flex items-center gap-3 p-2 rounded-lg text-left hover:bg-[#e7e8e9] transition-all cursor-pointer"
        >
          <div className="w-8 h-8 rounded-full bg-[#004485] flex items-center justify-center text-white font-bold text-xs shrink-0">
            SK
          </div>
          <div className="overflow-hidden">
            <p className="text-xs font-bold text-[#191c1d] truncate">S. Kulkarni</p>
            <p className="text-[10px] text-[#424751] uppercase tracking-wider font-semibold">
              Dy. Secretary
            </p>
          </div>
        </button>
      </div>
    </aside>
  );
};
