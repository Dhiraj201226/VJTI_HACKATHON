import React from 'react';

export const OfficerProfileView: React.FC = () => {
  return (
    <div className="space-y-6 max-w-4xl mx-auto w-full pb-10">
      <div className="bg-white p-8 border border-[#c2c6d3] rounded-xl shadow-2xs flex flex-col md:flex-row items-center gap-6">
        <img
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuBhvBQNv7-vIEGrpIu_NOhQhvrL2jKF6Y-_caNIvWuQfzfclnUsz9FdGxwa6JTAed-KW5LlpPwevbzX45NN4dNCn7HSQkgQrJeE4iNGwBWHPs-1gg5rDOXdqHksmoVq83EXlh52WQE0XWWDueAW_VDV4FkGatt75G0tVL8ivoYbje1oP4wx3C_e9tKhWPvLy2wpLwMXB9DhpMhx59pQL06moT2-T30RnM4o5T9NW25GxRMUyAsv0Nymwmyz2FgFbk-cNa9g2x2bDyU"
          alt="Officer Headshot"
          className="w-28 h-28 rounded-full border-4 border-[#004485] object-cover shadow-md"
          referrerPolicy="no-referrer"
        />
        <div className="text-center md:text-left">
          <span className="px-3 py-1 bg-[#d5e3ff] text-[#004485] font-bold text-[10px] uppercase rounded-full tracking-wider">
            Authorized Signatory
          </span>
          <h1 className="font-poppins text-2xl font-bold text-[#191c1d] mt-2">S. Kulkarni</h1>
          <p className="text-sm font-semibold text-[#004485]">Deputy Secretary, Finance Department</p>
          <p className="text-xs text-[#424751] mt-1">Government of Maharashtra, Mantralaya, Mumbai</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white border border-[#c2c6d3] p-6 rounded-xl shadow-2xs space-y-3">
          <h3 className="font-poppins font-bold text-sm text-[#004485]">Departmental Credentials</h3>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between border-b pb-1.5">
              <span className="text-[#424751]">Officer ID:</span>
              <span className="font-mono font-bold text-[#191c1d]">MHA-GOV-88219</span>
            </div>
            <div className="flex justify-between border-b pb-1.5">
              <span className="text-[#424751]">Designation:</span>
              <span className="font-bold text-[#191c1d]">Deputy Secretary</span>
            </div>
            <div className="flex justify-between border-b pb-1.5">
              <span className="text-[#424751]">Department:</span>
              <span className="font-bold text-[#191c1d]">Finance Department</span>
            </div>
            <div className="flex justify-between border-b pb-1.5">
              <span className="text-[#424751]">Security Clearance:</span>
              <span className="font-bold text-emerald-600">Level-5 (Cabinet &amp; GR Signatory)</span>
            </div>
          </div>
        </div>

        <div className="bg-white border border-[#c2c6d3] p-6 rounded-xl shadow-2xs space-y-3">
          <h3 className="font-poppins font-bold text-sm text-[#004485]">Signing Statistics</h3>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between border-b pb-1.5">
              <span className="text-[#424751]">GRs Approved (2024):</span>
              <span className="font-bold text-[#191c1d]">184 Documents</span>
            </div>
            <div className="flex justify-between border-b pb-1.5">
              <span className="text-[#424751]">Average Approval Time:</span>
              <span className="font-bold text-[#191c1d]">1.8 Hours</span>
            </div>
            <div className="flex justify-between border-b pb-1.5">
              <span className="text-[#424751]">Zero-Conflict Rate:</span>
              <span className="font-bold text-emerald-600">99.2%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
