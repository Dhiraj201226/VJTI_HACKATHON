import React, { useState } from 'react';
import { GRDocument, NavView } from '../types';

interface OfficialDocumentPreviewViewProps {
  doc: GRDocument;
  setCurrentView: (view: NavView) => void;
}

export const OfficialDocumentPreviewView: React.FC<
  OfficialDocumentPreviewViewProps
> = ({ doc, setCurrentView }) => {
  const [downloadingFormat, setDownloadingFormat] = useState<string | null>(null);

  const handleDownload = (type: string) => {
    setDownloadingFormat(type);
    setTimeout(() => {
      setDownloadingFormat(null);
      if (type === 'PDF') {
        window.print();
      }
    }, 800);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto w-full pb-10">
      {/* Top Banner Action Row */}
      <div className="bg-white p-4 border border-[#c2c6d3] rounded-xl flex flex-wrap justify-between items-center gap-4 no-print shadow-2xs">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentView('review')}
            className="flex items-center gap-1 text-xs text-[#004485] font-bold hover:underline cursor-pointer"
          >
            <span className="material-symbols-outlined text-sm">arrow_back</span>
            Back to Review
          </button>
          <div className="h-4 w-px bg-[#c2c6d3]"></div>
          <span className="text-xs font-bold text-[#191c1d]">
            Official Alignment Preview &amp; Issue Ready
          </span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => window.print()}
            className="bg-white border border-[#004485] text-[#004485] px-4 py-2 rounded-lg font-bold text-xs flex items-center gap-1.5 hover:bg-[#f3f4f5] transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-base">print</span>
            Print Resolution
          </button>
          <button
            onClick={() => handleDownload('PDF')}
            className="bg-[#004485] text-white px-5 py-2 rounded-lg font-bold text-xs flex items-center gap-1.5 hover:bg-[#0b5cad] transition-colors cursor-pointer shadow-2xs"
          >
            <span className="material-symbols-outlined text-base">picture_as_pdf</span>
            Download Official PDF
          </button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        {/* Document Sheet Area */}
        <div className="col-span-12 lg:col-span-9 bg-white p-10 md:p-14 document-container border border-[#c2c6d3] rounded-xl shadow-md overflow-hidden">
          {/* Official Header */}
          <div className="flex flex-col items-center text-center mb-8 border-b-2 border-[#004485] pb-6">
            <img
              className="h-20 w-20 mb-3 object-contain"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuBCm2TCvSvetJVdbPr1U5T2q80skjHyX3qA7b0TmMzDzTKFYVYkFUXeLeCnXbYiinkT75O0oXWA0LTXj5aK4Tz8wbnDs-63nuZD3Y3JpFGigVeEU9cHWxXussJfqxuWNs27UPPkGCUCw0OT7wivhj529rOL7YQ-F1D3uX5qrbN1UbJ-yVOQtGYUoXCtIeAJiZHKu9iCP0npP0calF6sO89iEe9x3Do3X-PXBHmSVgjYPWFI-Ux4tBZjHK2B9oR79Yes-tPLzOJCoYw"
              alt="Government of Maharashtra Seal"
              referrerPolicy="no-referrer"
            />
            <h1 className="font-poppins text-2xl font-bold text-[#001b3c] uppercase tracking-wide">
              Government of Maharashtra
            </h1>
            <p className="font-poppins text-base font-semibold text-[#424751]">
              {doc.department || 'General Administration Department'}
            </p>
            <p className="text-xs text-[#424751] mt-0.5">Mantralaya, Mumbai 400 032</p>

            <div className="w-full flex justify-between mt-6 text-xs text-[#191c1d] border-t border-[#c2c6d3] pt-2 font-mono">
              <span>No: {doc.refNo}</span>
              <span>Date: {doc.generatedDate}</span>
            </div>
          </div>

          {/* Subject & References */}
          <div className="space-y-4 mb-8">
            <div className="flex flex-col md:flex-row gap-2">
              <span className="font-bold min-w-[90px] text-xs uppercase text-[#191c1d]">
                Subject:
              </span>
              <div className="font-bold text-[#191c1d] font-document-text text-base uppercase underline decoration-1 underline-offset-4 leading-relaxed">
                {doc.title.toUpperCase()}
              </div>
            </div>

            <div className="flex flex-col md:flex-row gap-2 bg-[#f3f4f5] p-4 rounded border border-[#c2c6d3]">
              <span className="font-bold min-w-[90px] text-xs uppercase text-[#191c1d]">
                References:
              </span>
              <ol className="list-decimal list-inside space-y-1 text-xs text-[#191c1d] font-sans">
                {doc.references && doc.references.length > 0 ? (
                  doc.references.map((ref, idx) => <li key={idx}>{ref}</li>)
                ) : (
                  <>
                    <li>
                      Government Resolution, Information Technology Dept., No. ITD-402/2023, Dated
                      15.01.2023
                    </li>
                    <li>Maharashtra Digital Transformation Act, Section 14 (v), Clause B.</li>
                    <li>Minutes of the meeting held by the Chief Secretary on 10th September 2024.</li>
                  </>
                )}
              </ol>
            </div>
          </div>

          {/* Preamble / Introduction */}
          <div className="font-document-text text-base leading-relaxed mb-8 text-[#191c1d]">
            <p className="indent-10 text-justify">{doc.preamble}</p>
          </div>

          {/* Government Resolution Clauses */}
          <div className="space-y-4 mb-10">
            <h2 className="font-poppins text-lg font-bold text-[#004485] uppercase border-l-4 border-[#004485] pl-3 mb-4">
              Government Resolution
            </h2>

            <div className="grid grid-cols-[30px_1fr] gap-2 font-document-text text-base">
              <span className="font-bold">1.</span>
              <div>
                The GAD hereby mandates the use of the "MAHA-GR ALIGN" portal for the initial
                drafting, semantic checking, and cross-reference validation of all incoming and
                outgoing Government Resolutions effective from 1st November 2024.
              </div>
            </div>

            <div className="grid grid-cols-[30px_1fr] gap-2 font-document-text text-base">
              <span className="font-bold">2.</span>
              <div>{doc.financialProvisions}</div>
            </div>

            <div className="grid grid-cols-[30px_1fr] gap-2 font-document-text text-base">
              <span className="font-bold">3.</span>
              <div>{doc.technicalSpecs}</div>
            </div>

            <div className="grid grid-cols-[30px_1fr] gap-2 font-document-text text-base">
              <span className="font-bold">4.</span>
              <div>{doc.implementationBody}</div>
            </div>
          </div>

          {/* Signature Block */}
          <div className="mt-16 flex flex-col items-end">
            <div className="text-center min-w-[280px]">
              <p className="text-xs text-[#191c1d]">
                By order and in the name of the Governor of Maharashtra,
              </p>
              <div className="my-8 h-12 border-b border-dashed border-[#c2c6d3] w-full opacity-60"></div>
              <p className="font-bold font-poppins text-sm text-[#191c1d]">
                (Rajendra P. Deshmukh)
              </p>
              <p className="text-xs text-[#424751]">Secretary to Government,</p>
              <p className="text-xs text-[#424751]">General Administration Department</p>
            </div>
          </div>

          {/* Distribution list */}
          <div className="mt-12 pt-6 border-t border-[#c2c6d3] text-xs text-[#424751]">
            <p className="font-bold mb-2 text-[#191c1d]">Copy to:</p>
            <ul className="list-disc list-inside space-y-1 ml-2">
              {doc.copiesTo && doc.copiesTo.length > 0 ? (
                doc.copiesTo.map((item, i) => <li key={i}>{item}</li>)
              ) : (
                <>
                  <li>The Hon. Governor’s Secretariat, Raj Bhavan, Mumbai.</li>
                  <li>The Hon. Chief Minister’s Secretariat, Mantralaya.</li>
                  <li>The Chief Secretary, Maharashtra State.</li>
                  <li>All Additional Chief Secretaries / Principal Secretaries.</li>
                  <li>Accountant General (A&amp;E), Maharashtra, Mumbai/Nagpur.</li>
                </>
              )}
            </ul>
          </div>
        </div>

        {/* Right Control Sidebar */}
        <div className="col-span-12 lg:col-span-3 space-y-5 no-print">
          {/* Export Options */}
          <div className="bg-white border border-[#c2c6d3] rounded-xl p-5 shadow-2xs">
            <h3 className="font-poppins text-sm font-bold text-[#004485] mb-3 flex items-center gap-2">
              <span className="material-symbols-outlined text-lg">download</span>
              Export Options
            </h3>
            <div className="flex flex-col gap-2">
              <button
                onClick={() => handleDownload('PDF')}
                disabled={downloadingFormat !== null}
                className="w-full bg-[#004485] text-white py-2.5 rounded-lg font-bold text-xs flex items-center justify-center gap-2 hover:bg-[#0b5cad] transition-opacity cursor-pointer shadow-2xs"
              >
                {downloadingFormat === 'PDF' ? (
                  <span className="material-symbols-outlined animate-spin text-sm">sync</span>
                ) : (
                  <span className="material-symbols-outlined text-base">picture_as_pdf</span>
                )}
                Download PDF
              </button>

              <button
                onClick={() => handleDownload('DOCX')}
                disabled={downloadingFormat !== null}
                className="w-full border border-[#0f61a4] text-[#0f61a4] py-2.5 rounded-lg font-bold text-xs flex items-center justify-center gap-2 hover:bg-[#d5e3ff]/40 transition-colors cursor-pointer"
              >
                {downloadingFormat === 'DOCX' ? (
                  <span className="material-symbols-outlined animate-spin text-sm">sync</span>
                ) : (
                  <span className="material-symbols-outlined text-base">description</span>
                )}
                Download DOCX
              </button>
            </div>
          </div>

          {/* Compliance Status Card */}
          <div className="bg-white border border-[#c2c6d3] rounded-xl overflow-hidden shadow-2xs">
            <div className="bg-[#004485] text-white px-4 py-2 font-bold text-[11px] uppercase tracking-wider">
              Document Status
            </div>
            <div className="p-4 space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-medium text-[#191c1d]">Compliance Score</span>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded text-[11px] font-bold uppercase">
                  98% PASSED
                </span>
              </div>
              <div className="w-full bg-[#e7e8e9] h-2 rounded-full overflow-hidden">
                <div className="bg-emerald-500 h-full w-[98%]"></div>
              </div>
              <div className="flex justify-between items-center pt-1 border-t border-[#f3f4f5]">
                <span className="text-xs font-medium text-[#191c1d]">Formatting Status</span>
                <div className="flex items-center gap-1 text-emerald-600">
                  <span className="material-symbols-outlined text-sm">check_circle</span>
                  <span className="text-xs font-bold">Standardized</span>
                </div>
              </div>
            </div>
          </div>

          {/* Checklist */}
          <div className="bg-white border border-[#c2c6d3] rounded-xl p-5 shadow-2xs">
            <h3 className="font-poppins text-sm font-bold text-[#191c1d] mb-3">Checklist</h3>
            <div className="space-y-2.5 text-xs">
              <label className="flex items-center gap-2.5">
                <input type="checkbox" defaultChecked className="rounded text-[#004485]" />
                <span>Official emblem attached and centered</span>
              </label>
              <label className="flex items-center gap-2.5">
                <input type="checkbox" defaultChecked className="rounded text-[#004485]" />
                <span>Reference numbers cross-verified</span>
              </label>
              <label className="flex items-center gap-2.5">
                <input type="checkbox" defaultChecked className="rounded text-[#004485]" />
                <span>Departmental hierarchy verified</span>
              </label>
              <label className="flex items-center gap-2.5 opacity-60">
                <input type="checkbox" className="rounded text-[#004485]" />
                <span>Digital signature token active</span>
              </label>
              <label className="flex items-center gap-2.5 opacity-60">
                <input type="checkbox" className="rounded text-[#004485]" />
                <span>Copy list (distribution) finalized</span>
              </label>
            </div>
          </div>

          {/* AI Recommendation */}
          <div className="bg-[#77b4fd]/20 border border-[#77b4fd] rounded-xl p-4 flex gap-3 shadow-2xs">
            <span className="material-symbols-outlined text-[#0f61a4] text-xl shrink-0">
              psychology
            </span>
            <div className="text-xs">
              <span className="font-bold text-[#00457a] block mb-1">AI Recommendation</span>
              <p className="text-[#191c1d] leading-snug">
                Clause 2 uses a restrictive adjective. To match standard state protocols, consider
                using "shall" instead of "must" for inter-departmental mandates.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
