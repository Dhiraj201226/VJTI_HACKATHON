import React, { useState } from 'react';
import { GRDocument, NavView, ValidationSession, ConflictRecord } from '../types';

interface CreateGRViewProps {
  onGenerate: (newDoc: GRDocument) => void;
  setValidationSession: React.Dispatch<React.SetStateAction<ValidationSession>>;
  setCurrentView: (view: NavView) => void;
}

export const CreateGRView: React.FC<CreateGRViewProps> = ({
  onGenerate,
  setValidationSession,
  setCurrentView,
}) => {
  const [objective, setObjective] = useState('');
  const [department, setDepartment] = useState('Home Department');
  const [policyCategory, setPolicyCategory] = useState('Financial Allocation');
  const [priority, setPriority] = useState<'Standard' | 'Urgent' | 'Critical'>('Critical');
  const [language, setLanguage] = useState<'Marathi' | 'English'>('Marathi');
  const [officerNotes, setOfficerNotes] = useState('');
  const [supportingDocs, setSupportingDocs] = useState<string[]>(['Court_Order_Ref_4421.pdf']);
  const [isGenerating, setIsGenerating] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const fileNames = Array.from(e.target.files).map((f: File) => f.name);
      setSupportingDocs((prev) => [...prev, ...fileNames]);
    }
  };

  const handleRemoveDoc = (index: number) => {
    setSupportingDocs((prev) => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const effectiveObjective = objective.trim() || 'Sanctioning of funds for modernizing district courts in Vidarbha region';

    setIsGenerating(true);

    try {
      const res = await fetch('/api/generate-gr', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          objective: effectiveObjective,
          department,
          policyCategory,
          priority,
          language,
          officerNotes,
          supportingDocs,
        }),
      });

      const json = await res.json();
      let generatedDoc: GRDocument;

      if (json.success && json.data) {
        generatedDoc = {
          ...json.data,
          status: 'Conflict',
          supportingDocs,
        };
      } else {
        throw new Error(json.error || 'Failed to generate draft');
      }

      // Initial detected conflicts for this newly generated draft
      const initialConflicts: ConflictRecord[] = [
        {
          id: 'CONF-NEW-001',
          conflictType: 'Timeline mismatch',
          oldGRNumber: 'GR No. 2023/FIN-88',
          newGRNumber: generatedDoc.refNo,
          oldStatement: 'Clause 4.1: Capital outlays exceeding ₹100 Crores shall strictly be released in four quarterly tranches linked to QPR.',
          newStatement: generatedDoc.financialProvisions || 'A budgetary outlay of ₹350 Crores shall be released in Q1 as a lump-sum grant.',
          reasonForContradiction: 'Lump-sum disbursement in Q1 violates mandatory quarterly tranche regulation specified in GR No. 2023/FIN-88.',
          sourceReferences: {
            oldDept: 'Finance Department',
            newDept: department,
            oldGRTitle: 'Financial Procurement Timelines (GR No. 2023/FIN-88)',
            date: '12/05/2023',
          },
          status: 'Pending',
          sourceGR: generatedDoc.title,
          sourceGRNumber: generatedDoc.refNo,
          sourceDept: department,
          targetGR: 'Financial Procurement Timelines (GR No. 2023/FIN-88)',
          targetDept: 'Finance Department',
          date: '12/05/2023',
          severity: 'High',
          description: 'Lump-sum disbursement schedule conflicts with mandatory quarterly tranche rule for capital grants.',
          existingClause: generatedDoc.financialProvisions || 'A budgetary outlay of ₹350 Crores shall be released in Q1.',
          conflictingClause: 'GR No. 2023/FIN-88 Clause 4.1: Capital outlays exceeding ₹100 Crores shall strictly be released in four quarterly tranches linked to QPR.',
          clauseOverlap: 'Lump-sum release in Q1 violates mandatory quarterly tranche regulation.',
          aiExplanation: 'Finance rules mandate that grants exceeding ₹100 Crores be disbursed in four equal quarterly tranches tied to Quarterly Progress Reports.',
          aiFixSuggestion: 'Modify financial provisions to 4 equal quarterly tranches of 25% each linked to certified QPR submissions.',
          recommendationOptions: [
            'Option 1: Keep the OLD Government Resolution statement (Release in 4 quarterly tranches).',
            'Option 2: Use the NEW Government Resolution statement (Release as annual lump-sum in Q1).',
            'Option 3: Custom Statement'
          ],
          confidenceScore: 98
        },
        {
          id: 'CONF-NEW-002',
          conflictType: 'Department ownership mismatch',
          oldGRNumber: 'GR No. 2024/GAD-101',
          newGRNumber: generatedDoc.refNo,
          oldStatement: 'Clause 3: All inter-departmental initiatives exceeding ₹200 Cr require explicit co-signature from Principal Secretary GAD.',
          newStatement: generatedDoc.implementationBody || 'Executing agency shall coordinate with District Collectors.',
          reasonForContradiction: 'Single departmental execution agency lacks required GAD Nodal co-signatory for initiatives over ₹200 Crores.',
          sourceReferences: {
            oldDept: 'General Administration Department',
            newDept: department,
            oldGRTitle: 'Inter-Departmental Nodal Agency & Authority Rules (GR No. 2024/GAD-101)',
            date: '10/01/2024',
          },
          status: 'Pending',
          sourceGR: generatedDoc.title,
          sourceGRNumber: generatedDoc.refNo,
          sourceDept: department,
          targetGR: 'Inter-Departmental Nodal Agency & Authority Rules (GR No. 2024/GAD-101)',
          targetDept: 'General Administration Department',
          date: '10/01/2024',
          severity: 'Medium',
          description: 'Implementation authority requires joint Nodal Agency co-signing for major infrastructure outlays.',
          existingClause: generatedDoc.implementationBody || 'Executing agency shall coordinate with District Collectors.',
          conflictingClause: 'GR No. 2024/GAD-101 Clause 3: All inter-departmental initiatives exceeding ₹200 Cr require explicit co-signature from Principal Secretary GAD.',
          clauseOverlap: 'Single departmental execution agency lacks required GAD Nodal co-signatory.',
          aiExplanation: 'Projects over ₹200 Crores crossing departmental boundaries require joint execution oversight with General Administration Department.',
          aiFixSuggestion: 'Include Principal Secretary (GAD) as co-chair of the Implementation Steering Committee.',
          recommendationOptions: [
            'Option 1: Keep the OLD Government Resolution statement (Require GAD co-signature).',
            'Option 2: Use the NEW Government Resolution statement (Departmental execution agency).',
            'Option 3: Custom Statement'
          ],
          confidenceScore: 94
        }
      ];

      onGenerate(generatedDoc);

      setValidationSession((prev) => ({
        ...prev,
        activeDraft: generatedDoc,
        conflicts: initialConflicts,
        iteration: 1,
        isLoopComplete: false,
      }));

      // Directly open Conflict Review page as per user flow
      setCurrentView('conflicts');
    } catch (err: any) {
      console.error('Draft generation error:', err);
      // Fallback draft
      const fallbackDoc: GRDocument = {
        id: `DRAFT_ID_${Math.floor(1000 + Math.random() * 9000)}_REV`,
        refNo: `GAD-2024/CR-${Math.floor(100 + Math.random() * 900)}/E-GOV`,
        title: effectiveObjective,
        department,
        policyCategory,
        priority,
        language,
        generatedDate: new Date().toLocaleDateString('en-US', {
          month: 'long',
          day: 'numeric',
          year: 'numeric',
        }),
        status: 'Conflict',
        preamble: `In alignment with e-Governance initiatives and state priorities, the Government of Maharashtra hereby approves the administrative provisions for ${effectiveObjective}.`,
        financialProvisions:
          'The cabinet has sanctioned a budgetary outlay of ₹350 Crores for the current fiscal year. Funds shall be disbursed in a single tranche.',
        complianceRisk:
          'The disbursement timeline mentioned lacks specific quarterly targets mandated by GR No. 2023/FIN-88.',
        technicalSpecs:
          'All execution units must conform strictly to state standards and ISO security benchmarks.',
        implementationBody:
          'The executing agency shall coordinate with District Collectors and submit monthly progress reports.',
        signatory: 'A. K. Deshmukh',
        signatoryTitle: 'Section Officer',
        officerNotes,
        complianceScore: 84,
        formattingStatus: 'Needs Alignment',
        references: [
          'Government Resolution, Information Technology Dept., No. ITD-402/2023',
          'Maharashtra Digital Transformation Act, Section 14 (v)',
        ],
        copiesTo: [
          "The Hon. Governor's Secretariat, Raj Bhavan, Mumbai.",
          "The Hon. Chief Minister's Secretariat, Mantralaya.",
          'The Chief Secretary, Maharashtra State.',
        ],
        supportingDocs,
      };

      const fallbackConflicts: ConflictRecord[] = [
        {
          id: 'CONF-FB-001',
          conflictType: 'Timeline mismatch',
          oldGRNumber: 'GR No. 2023/FIN-88',
          newGRNumber: fallbackDoc.refNo,
          oldStatement: 'Clause 4.1: Capital outlays exceeding ₹100 Crores shall strictly be released in four quarterly tranches linked to QPR.',
          newStatement: fallbackDoc.financialProvisions,
          reasonForContradiction: 'Single-tranche fund release violates quarterly tranche mandate for outlays over ₹100 Cr specified in GR No. 2023/FIN-88.',
          sourceReferences: {
            oldDept: 'Finance Department',
            newDept: department,
            oldGRTitle: 'Financial Procurement Timelines (GR No. 2023/FIN-88)',
            date: '12/05/2023',
          },
          status: 'Pending',
          sourceGR: fallbackDoc.title,
          sourceGRNumber: fallbackDoc.refNo,
          sourceDept: department,
          targetGR: 'Financial Procurement Timelines (GR No. 2023/FIN-88)',
          targetDept: 'Finance Department',
          date: '12/05/2023',
          severity: 'High',
          description: 'Single-tranche fund release violates quarterly tranche mandate for outlays over ₹100 Cr.',
          existingClause: fallbackDoc.financialProvisions,
          conflictingClause: 'GR No. 2023/FIN-88 Clause 4.1: Capital outlays exceeding ₹100 Crores shall strictly be released in four quarterly tranches linked to QPR.',
          clauseOverlap: 'Single-tranche disbursement violates mandatory quarterly tranche regulation.',
          aiExplanation: 'Finance rules mandate that grants exceeding ₹100 Crores be disbursed in four equal quarterly tranches tied to Quarterly Progress Reports.',
          aiFixSuggestion: 'Modify financial provisions to 4 equal quarterly tranches of 25% each linked to certified QPR submissions.',
          recommendationOptions: [
            'Option 1: Keep the OLD Government Resolution statement (Release in 4 quarterly tranches).',
            'Option 2: Use the NEW Government Resolution statement (Release in a single tranche).',
            'Option 3: Custom Statement'
          ],
          confidenceScore: 97
        }
      ];

      onGenerate(fallbackDoc);

      setValidationSession((prev) => ({
        ...prev,
        activeDraft: fallbackDoc,
        conflicts: fallbackConflicts,
        iteration: 1,
        isLoopComplete: false,
      }));

      setCurrentView('conflicts');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="bg-white border border-[#c2c6d3] rounded-xl p-8 max-w-3xl mx-auto shadow-2xs mb-10">
      <header className="mb-6 border-b border-[#e1e3e4] pb-4">
        <h2 className="font-poppins text-2xl font-bold text-[#004485] mb-1">
          Government Resolution Parameters
        </h2>
        <p className="text-sm text-[#424751]">
          Fill in the institutional requirements to initiate the AI-assisted drafting process.
        </p>
      </header>

      {errorMessage && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 text-[#ba1a1a] rounded text-xs">
          {errorMessage}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Objective & Subject Line */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#191c1d] block">
            Objective &amp; Subject Line
          </label>
          <textarea
            value={objective}
            onChange={(e) => setObjective(e.target.value)}
            rows={3}
            className="w-full border border-[#c2c6d3] rounded-lg p-3 text-sm focus:border-[#004485] focus:ring-1 focus:ring-[#004485] outline-none text-[#191c1d]"
            placeholder="e.g., Sanctioning of funds for modernizing district courts in Vidarbha region..."
          />
        </div>

        {/* Dropdowns row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-[#191c1d] block">Department</label>
            <select
              value={department}
              onChange={(e) => setDepartment(e.target.value)}
              className="w-full border border-[#c2c6d3] rounded-lg p-2.5 text-sm focus:border-[#004485] outline-none bg-white text-[#191c1d]"
            >
              <option value="Home Department">Home Department</option>
              <option value="Finance Department">Finance Department</option>
              <option value="Revenue & Forest">Revenue &amp; Forest</option>
              <option value="Law & Judiciary">Law &amp; Judiciary</option>
              <option value="Public Health">Public Health</option>
              <option value="School Education">School Education</option>
              <option value="Energy & Infrastructure Department">
                Energy &amp; Infrastructure Department
              </option>
              <option value="IT & Communication">IT &amp; Communication</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-[#191c1d] block">Policy Category</label>
            <select
              value={policyCategory}
              onChange={(e) => setPolicyCategory(e.target.value)}
              className="w-full border border-[#c2c6d3] rounded-lg p-2.5 text-sm focus:border-[#004485] outline-none bg-white text-[#191c1d]"
            >
              <option value="Financial Allocation">Financial Allocation</option>
              <option value="Appointment/Recruitment">Appointment/Recruitment</option>
              <option value="New Infrastructure">New Infrastructure</option>
              <option value="Public Policy Amendment">Public Policy Amendment</option>
            </select>
          </div>
        </div>

        {/* Priority & Language Mode row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Priority */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-[#191c1d] block">Priority Level</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setPriority('Standard')}
                className={`flex-1 py-2 px-3 border rounded text-xs transition-all cursor-pointer ${
                  priority === 'Standard'
                    ? 'border-[#004485] bg-[#d5e3ff]/30 text-[#004485] font-bold'
                    : 'border-[#c2c6d3] text-[#424751] hover:bg-[#f3f4f5]'
                }`}
              >
                Standard
              </button>
              <button
                type="button"
                onClick={() => setPriority('Urgent')}
                className={`flex-1 py-2 px-3 border rounded text-xs transition-all cursor-pointer ${
                  priority === 'Urgent'
                    ? 'border-amber-600 bg-amber-50 text-amber-800 font-bold'
                    : 'border-[#c2c6d3] text-[#424751] hover:bg-[#f3f4f5]'
                }`}
              >
                Urgent
              </button>
              <button
                type="button"
                onClick={() => setPriority('Critical')}
                className={`flex-1 py-2 px-3 border rounded text-xs transition-all cursor-pointer ${
                  priority === 'Critical'
                    ? 'border-[#ba1a1a] text-[#ba1a1a] font-bold bg-[#ffdad6]/30'
                    : 'border-[#c2c6d3] text-[#424751] hover:bg-[#f3f4f5]'
                }`}
              >
                Critical
              </button>
            </div>
          </div>

          {/* Language Mode */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-[#191c1d] block">Language Mode</label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setLanguage('Marathi')}
                className={`flex-1 py-2 px-3 border text-xs rounded transition-all cursor-pointer ${
                  language === 'Marathi'
                    ? 'border-[#004485] text-[#004485] font-bold bg-[#0b5cad]/10'
                    : 'border-[#c2c6d3] text-[#424751] hover:bg-[#f3f4f5]'
                }`}
              >
                Marathi (Primary)
              </button>
              <button
                type="button"
                onClick={() => setLanguage('English')}
                className={`flex-1 py-2 px-3 border text-xs rounded transition-all cursor-pointer ${
                  language === 'English'
                    ? 'border-[#004485] text-[#004485] font-bold bg-[#0b5cad]/10'
                    : 'border-[#c2c6d3] text-[#424751] hover:bg-[#f3f4f5]'
                }`}
              >
                English
              </button>
            </div>
          </div>
        </div>

        {/* Officer Confidential Notes */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold text-[#191c1d] block">
            Officer Confidential Notes
          </label>
          <textarea
            value={officerNotes}
            onChange={(e) => setOfficerNotes(e.target.value)}
            rows={3}
            className="w-full border border-[#c2c6d3] rounded-lg p-3 text-sm focus:border-[#004485] focus:ring-1 focus:ring-[#004485] outline-none text-[#191c1d]"
            placeholder="Internal justifications, reference to past cabinet meetings, or specific clauses to include..."
          />
        </div>

        {/* Supporting Documents */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-[#191c1d] block">
            Supporting Documents (PDF/DOCX)
          </label>

          <label className="border-2 border-dashed border-[#c2c6d3] rounded-lg p-6 flex flex-col items-center justify-center text-center bg-white hover:bg-[#f3f4f5] transition-all cursor-pointer group">
            <input
              type="file"
              multiple
              accept=".pdf,.docx,.doc"
              onChange={handleFileUpload}
              className="hidden"
            />
            <span className="material-symbols-outlined text-4xl text-[#004485] mb-1 group-hover:scale-110 transition-transform">
              cloud_upload
            </span>
            <p className="text-xs text-[#191c1d] font-semibold">Click to upload or drag and drop</p>
            <p className="text-[10px] text-[#424751] font-bold uppercase tracking-wider mt-0.5">
              MAX SIZE 25MB PER FILE
            </p>
          </label>

          {/* File item chips */}
          {supportingDocs.length > 0 && (
            <div className="mt-2 space-y-2">
              {supportingDocs.map((file, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2.5 bg-[#e7e8e9] rounded border border-[#c2c6d3]"
                >
                  <div className="flex items-center gap-2.5 text-xs text-[#191c1d]">
                    <span className="material-symbols-outlined text-[#004485] text-lg">
                      description
                    </span>
                    <span className="font-medium">{file}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveDoc(idx)}
                    className="text-[#ba1a1a] hover:scale-110 transition-transform cursor-pointer"
                  >
                    <span className="material-symbols-outlined text-lg">cancel</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Submit button */}
        <div className="pt-6 border-t border-[#e1e3e4]">
          <button
            type="submit"
            disabled={isGenerating}
            className="w-full bg-[#0b5cad] text-white py-3.5 rounded-lg font-poppins font-semibold text-base shadow-md hover:brightness-110 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99] disabled:opacity-75"
          >
            {isGenerating ? (
              <>
                <span className="material-symbols-outlined animate-spin text-xl">sync</span>
                Analyzing 142,000+ GRs &amp; Generating Draft...
              </>
            ) : (
              <>
                <span className="material-symbols-filled text-xl">psychology</span>
                Generate AI Draft Resolution
              </>
            )}
          </button>
          <p className="text-center text-xs text-[#424751] mt-3">
            Drafting engine will analyze 142,000+ past GRs for semantic alignment.
          </p>
        </div>
      </form>
    </div>
  );
};
