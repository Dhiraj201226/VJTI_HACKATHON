import React from 'react';
import { GRDocument, NavView, NotificationItem } from '../types';

interface DashboardViewProps {
  documents: GRDocument[];
  notifications: NotificationItem[];
  setCurrentView: (view: NavView) => void;
  setSelectedDoc: (doc: GRDocument) => void;
  onMarkAllNotificationsRead: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  documents,
  notifications,
  setCurrentView,
  setSelectedDoc,
  onMarkAllNotificationsRead,
}) => {
  const publishedDocs = documents.filter((d) => d.status === 'Approved');

  const handleDownloadPDF = (doc: GRDocument) => {
    setSelectedDoc(doc);
    setCurrentView('preview');
  };

  const handleOpenDraft = (docId: string) => {
    const doc = documents.find((d) => d.id === docId || d.refNo.includes(docId));
    if (doc) {
      setSelectedDoc(doc);
      if (doc.status === 'Conflict' || doc.complianceRisk) {
        setCurrentView('review');
      } else {
        setCurrentView('review');
      }
    } else {
      setCurrentView('review');
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto w-full pb-8">
      {/* Welcome Banner */}
      <section className="relative overflow-hidden bg-[#0b5cad] text-white rounded-xl p-8 flex flex-col md:flex-row items-center justify-between shadow-xs border border-[#c2c6d3]">
        <div className="z-10 max-w-2xl">
          <h2 className="font-poppins text-2xl md:text-3xl font-semibold mb-2 text-white tracking-tight">
            Achuk Nirnay, Pragat Maharashtra
          </h2>
          <p className="text-sm md:text-base text-[#c0d6ff] opacity-90 mb-6 leading-relaxed">
            Streamline Maharashtra Government Resolutions with AI-powered semantic alignment and conflict detection. Ensure legal consistency across all departments in real-time.
          </p>
          <div className="flex flex-wrap gap-4">
            <button
              onClick={() => setCurrentView('create')}
              className="bg-white text-[#004485] px-6 py-2.5 rounded-lg font-bold hover:bg-[#d5e3ff] transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
            >
              <span className="material-symbols-outlined text-xl">add</span>
              Create New GR
            </button>
            <button
              onClick={() => setCurrentView('create')}
              className="border border-white text-white px-6 py-2.5 rounded-lg font-bold hover:bg-white/10 transition-colors flex items-center gap-2 cursor-pointer"
            >
              <span className="material-symbols-outlined text-xl">upload_file</span>
              Upload for Review
            </button>
          </div>
        </div>
        <div className="mt-8 md:mt-0 opacity-15 absolute right-0 top-0 h-full overflow-hidden pointer-events-none">
          <img
            alt="Government Seal Watermark"
            className="h-full scale-125 rotate-12 object-contain"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuBCm2TCvSvetJVdbPr1U5T2q80skjHyX3qA7b0TmMzDzTKFYVYkFUXeLeCnXbYiinkT75O0oXWA0LTXj5aK4Tz8wbnDs-63nuZD3Y3JpFGigVeEU9cHWxXussJfqxuWNs27UPPkGCUCw0OT7wivhj529rOL7YQ-F1D3uX5qrbN1UbJ-yVOQtGYUoXCtIeAJiZHKu9iCP0npP0calF6sO89iEe9x3Do3X-PXBHmSVgjYPWFI-Ux4tBZjHK2B9oR79Yes-tPLzOJCoYw"
            referrerPolicy="no-referrer"
          />
        </div>
      </section>

      {/* Quick Stats Grid */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white border border-[#c2c6d3] p-4 rounded-lg flex flex-col gap-1 shadow-2xs hover:border-[#004485] transition-colors">
          <div className="flex justify-between items-center mb-1">
            <span className="text-[11px] font-bold text-[#424751] uppercase tracking-wider">
              Total GRs Published
            </span>
            <span className="material-symbols-outlined text-[#004485]">public</span>
          </div>
          <div className="font-poppins text-2xl font-bold text-[#191c1d]">14,282</div>
          <div className="text-xs text-emerald-600 flex items-center gap-1 font-medium">
            <span className="material-symbols-outlined text-sm">trending_up</span>
            <span>+12 this month</span>
          </div>
        </div>

        <div className="bg-white border border-[#c2c6d3] p-4 rounded-lg flex flex-col gap-1 shadow-2xs hover:border-[#004485] transition-colors">
          <div className="flex justify-between items-center mb-1">
            <span className="text-[11px] font-bold text-[#424751] uppercase tracking-wider">
              Drafts in Progress
            </span>
            <span className="material-symbols-outlined text-[#0f61a4]">edit_note</span>
          </div>
          <div className="font-poppins text-2xl font-bold text-[#191c1d]">34</div>
          <div className="text-xs text-[#424751]">8 modified today</div>
        </div>

        <div className="bg-white border border-[#c2c6d3] p-4 rounded-lg flex flex-col gap-1 shadow-2xs hover:border-[#004485] transition-colors">
          <div className="flex justify-between items-center mb-1">
            <span className="text-[11px] font-bold text-[#424751] uppercase tracking-wider">
              Pending Review
            </span>
            <span className="material-symbols-outlined text-amber-600">pending_actions</span>
          </div>
          <div className="font-poppins text-2xl font-bold text-[#191c1d]">12</div>
          <div className="text-xs text-[#ba1a1a] flex items-center gap-1 font-semibold">
            <span className="material-symbols-outlined text-sm">priority_high</span>
            <span>4 Urgent status</span>
          </div>
        </div>

        <div className="bg-white border border-[#c2c6d3] p-4 rounded-lg flex flex-col gap-1 shadow-2xs hover:border-[#ba1a1a] transition-colors">
          <div className="flex justify-between items-center mb-1">
            <span className="text-[11px] font-bold text-[#424751] uppercase tracking-wider">
              Conflicts Found
            </span>
            <span className="material-symbols-outlined text-[#ba1a1a]">gavel</span>
          </div>
          <div className="font-poppins text-2xl font-bold text-[#191c1d]">07</div>
          <div className="text-xs text-[#424751]">Legal alignment needed</div>
        </div>
      </section>

      {/* Bento Dashboard Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column (8 cols): Recently Generated PDFs & Today's Drafts */}
        <div className="lg:col-span-8 space-y-6">
          {/* Recently Generated PDFs */}
          <div className="bg-white border border-[#c2c6d3] rounded-lg overflow-hidden shadow-2xs">
            <div className="px-6 py-4 border-b border-[#c2c6d3] flex justify-between items-center bg-[#f3f4f5]">
              <h3 className="font-poppins text-base font-semibold text-[#191c1d]">
                Recently Generated PDFs
              </h3>
              <button
                onClick={() => setCurrentView('documents')}
                className="text-[#004485] font-bold text-xs hover:underline cursor-pointer"
              >
                View All
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-[#001b3c] text-white text-[11px] font-bold uppercase tracking-wider">
                  <tr>
                    <th className="px-6 py-3">Document Title</th>
                    <th className="px-6 py-3">Department</th>
                    <th className="px-6 py-3">Generated Date</th>
                    <th className="px-6 py-3">Action</th>
                  </tr>
                </thead>
                <tbody className="text-xs divide-y divide-[#c2c6d3]">
                  {publishedDocs.slice(0, 3).map((doc, idx) => (
                    <tr
                      key={doc.id}
                      className={`${
                        idx % 2 === 1 ? 'bg-[#f3f4f5]' : 'bg-white'
                      } hover:bg-[#e7e8e9] transition-colors`}
                    >
                      <td className="px-6 py-3.5 font-semibold text-[#004485]">
                        <button
                          onClick={() => handleDownloadPDF(doc)}
                          className="hover:underline text-left cursor-pointer"
                        >
                          {doc.refNo}.pdf
                        </button>
                      </td>
                      <td className="px-6 py-3.5 text-[#191c1d]">{doc.department}</td>
                      <td className="px-6 py-3.5 text-[#424751]">{doc.generatedDate}</td>
                      <td className="px-6 py-3.5">
                        <button
                          onClick={() => handleDownloadPDF(doc)}
                          className="text-[#0f61a4] hover:text-[#004485] transition-colors cursor-pointer"
                          title="Download Document"
                        >
                          <span className="material-symbols-outlined text-lg">download</span>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Today's Drafts Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Card 1 */}
            <div className="bg-white border border-[#c2c6d3] rounded-lg p-5 hover:shadow-md transition-all flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start mb-3">
                  <div className="p-2 bg-[#0b5cad] rounded-lg text-white">
                    <span className="material-symbols-outlined text-lg">description</span>
                  </div>
                  <span className="bg-[#77b4fd]/20 text-[#00457a] font-bold text-[10px] px-2 py-0.5 rounded border border-[#0f61a4]/30 uppercase">
                    Draft
                  </span>
                </div>
                <h4 className="font-poppins font-semibold text-base text-[#191c1d] mb-1">
                  Smart City Phase II Allocation
                </h4>
                <p className="text-xs text-[#424751] mb-4">
                  Last edited by Officer K. Deshmukh at 10:45 AM today.
                </p>
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-[#f3f4f5]">
                <div className="flex -space-x-2">
                  <div className="w-6 h-6 rounded-full bg-[#d9dadb] border border-white"></div>
                  <div className="w-6 h-6 rounded-full bg-[#d5e3ff] border border-white"></div>
                </div>
                <button
                  onClick={() => handleOpenDraft('Smart City')}
                  className="text-[#004485] font-bold text-xs flex items-center gap-1 hover:underline cursor-pointer"
                >
                  Continue
                  <span className="material-symbols-outlined text-sm">arrow_forward</span>
                </button>
              </div>
            </div>

            {/* Card 2 */}
            <div className="bg-white border border-[#c2c6d3] rounded-lg p-5 hover:shadow-md transition-all flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start mb-3">
                  <div className="p-2 bg-[#385d92] rounded-lg text-white">
                    <span className="material-symbols-outlined text-lg">shield</span>
                  </div>
                  <span className="bg-amber-100 text-amber-800 font-bold text-[10px] px-2 py-0.5 rounded border border-amber-200 uppercase">
                    Reviewing
                  </span>
                </div>
                <h4 className="font-poppins font-semibold text-base text-[#191c1d] mb-1">
                  Public Safety Protocol Update
                </h4>
                <p className="text-xs text-[#424751] mb-4">
                  Semantic scan completed. 2 potential policy overlaps identified.
                </p>
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-[#f3f4f5]">
                <span className="text-[#ba1a1a] font-bold text-[11px] flex items-center gap-1">
                  <span className="material-symbols-outlined text-sm">warning</span>
                  High Conflict
                </span>
                <button
                  onClick={() => handleOpenDraft('Public Safety')}
                  className="text-[#004485] font-bold text-xs flex items-center gap-1 hover:underline cursor-pointer"
                >
                  View Report
                  <span className="material-symbols-outlined text-sm">arrow_forward</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (4 cols): Quick Actions & Recent Notifications */}
        <div className="lg:col-span-4 space-y-6">
          {/* Quick Actions */}
          <div className="bg-[#f3f4f5] border border-[#c2c6d3] rounded-lg p-5">
            <h3 className="text-[11px] font-bold text-[#424751] uppercase tracking-wider mb-3">
              Quick Actions
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setCurrentView('create')}
                className="flex flex-col items-center justify-center gap-2 p-4 bg-white border border-[#c2c6d3] rounded-lg hover:border-[#004485] hover:text-[#004485] transition-all cursor-pointer shadow-2xs group"
              >
                <span className="material-symbols-outlined text-2xl group-hover:scale-110 transition-transform text-[#004485]">
                  add_circle
                </span>
                <span className="text-xs font-bold text-[#191c1d] group-hover:text-[#004485]">
                  New GR
                </span>
              </button>

              <button
                onClick={() => setCurrentView('create')}
                className="flex flex-col items-center justify-center gap-2 p-4 bg-white border border-[#c2c6d3] rounded-lg hover:border-[#004485] hover:text-[#004485] transition-all cursor-pointer shadow-2xs group"
              >
                <span className="material-symbols-outlined text-2xl group-hover:scale-110 transition-transform text-[#0b5cad]">
                  auto_awesome
                </span>
                <span className="text-xs font-bold text-[#191c1d] group-hover:text-[#004485]">
                  AI Draft
                </span>
              </button>
            </div>
          </div>

          {/* Recent Notifications */}
          <div className="bg-white border border-[#c2c6d3] rounded-lg overflow-hidden shadow-2xs">
            <div className="px-5 py-3.5 border-b border-[#c2c6d3] bg-[#f3f4f5]">
              <h3 className="font-poppins font-semibold text-sm text-[#191c1d]">
                Recent Notifications
              </h3>
            </div>
            <div className="divide-y divide-[#c2c6d3]">
              {notifications.map((item) => (
                <div
                  key={item.id}
                  className="px-5 py-3.5 flex gap-3 hover:bg-[#e7e8e9] transition-colors cursor-pointer"
                  onClick={() => {
                    if (item.grRef) handleOpenDraft(item.grRef);
                  }}
                >
                  <div
                    className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${
                      item.type === 'conflict'
                        ? 'bg-[#ba1a1a]'
                        : item.type === 'policy'
                        ? 'bg-[#004485]'
                        : 'bg-transparent border border-[#c2c6d3]'
                    }`}
                  ></div>
                  <div className="flex-1 min-w-0">
                    <p
                      className={`text-xs font-semibold ${
                        item.type === 'conflict' ? 'text-[#ba1a1a]' : 'text-[#191c1d]'
                      }`}
                    >
                      {item.title}
                    </p>
                    <p className="text-[11px] text-[#424751] line-clamp-2 mt-0.5">
                      {item.description}
                    </p>
                    <p className="text-[10px] text-[#727783] mt-1">{item.timestamp}</p>
                  </div>
                </div>
              ))}
            </div>
            <button
              onClick={onMarkAllNotificationsRead}
              className="w-full py-2.5 text-xs text-[#004485] font-bold bg-[#f3f4f5] hover:bg-[#e7e8e9] border-t border-[#c2c6d3] transition-colors cursor-pointer"
            >
              Mark all as read
            </button>
          </div>
        </div>
      </div>

      {/* Floating Action Button */}
      <button
        onClick={() => setCurrentView('create')}
        className="fixed bottom-8 right-8 w-14 h-14 bg-[#004485] text-white rounded-full shadow-lg hover:shadow-xl flex items-center justify-center transition-all hover:scale-105 active:scale-95 z-50 cursor-pointer"
        title="Create New GR"
      >
        <span className="material-symbols-outlined text-2xl">add</span>
      </button>
    </div>
  );
};
