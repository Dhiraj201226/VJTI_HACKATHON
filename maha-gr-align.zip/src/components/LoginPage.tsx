import React, { useState } from 'react';
import { Building2, KeyRound, Mail, ShieldCheck, ArrowRight, Lock, Eye, EyeOff } from 'lucide-react';

interface LoginPageProps {
  onLogin: (officerEmail: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('s.kulkarni@maharashtra.gov.in');
  const [password, setPassword] = useState('••••••••••••');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin(email);
    }, 600);
  };

  return (
    <div className="min-h-screen bg-[#e7e8e9] flex flex-col justify-between selection:bg-[#004485] selection:text-white font-sans">
      {/* Top Banner Header */}
      <header className="bg-[#004485] text-white py-3 px-6 shadow-md border-b-4 border-[#ffb4a9]/80">
        <div className="max-w-7xl mx-auto flex justify-between items-center text-xs">
          <div className="flex items-center gap-3">
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuChD2VusDrbX1ZbmK8fxIRwrPWj72pwpHMmsocGUP7FGTem34djWfkgAoVcT5ZD_ggmCPYdv-6oaZRsD19scCQUj8SxPNcdZeMnOEQdmGDtF2gU2P5yfyapTd3CgNu-YqF2-sdd0Mb0MSV5RpmkyLu6TIoRlgtMcZnSYMJFmsm_3NaKv04e8QsfhiJA8N41LpzPmNzzfDSO32stQ5jNvskoPcwKKwnB_A1cOS97iGZy7jEYTLGkrkq4CMzaSaY0V8Ew47dmKP7POGA"
              alt="Government Emblem"
              className="w-10 h-10 object-contain drop-shadow-xs"
              referrerPolicy="no-referrer"
            />
            <div>
              <p className="font-poppins font-bold uppercase tracking-wider text-xs">
                Government of Maharashtra
              </p>
              <p className="text-[10px] text-blue-200 font-medium">
                Information Technology &amp; e-Governance Department
              </p>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-[11px] font-medium bg-white/10 px-3 py-1 rounded border border-white/20">
            <ShieldCheck className="w-4 h-4 text-emerald-300" />
            <span>Official Government Portal • Restricted Access</span>
          </div>
        </div>
      </header>

      {/* Main Login Card */}
      <main className="flex-1 flex items-center justify-center p-4 py-12">
        <div className="w-full max-w-md bg-white border border-[#c2c6d3] rounded-2xl shadow-lg overflow-hidden">
          {/* Header Section */}
          <div className="bg-[#f8f9fa] p-8 pb-6 border-b border-[#e1e3e4] text-center space-y-3">
            <div className="w-20 h-20 mx-auto mb-2 p-2 bg-white rounded-xl border border-[#c2c6d3] shadow-2xs flex items-center justify-center">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuChD2VusDrbX1ZbmK8fxIRwrPWj72pwpHMmsocGUP7FGTem34djWfkgAoVcT5ZD_ggmCPYdv-6oaZRsD19scCQUj8SxPNcdZeMnOEQdmGDtF2gU2P5yfyapTd3CgNu-YqF2-sdd0Mb0MSV5RpmkyLu6TIoRlgtMcZnSYMJFmsm_3NaKv04e8QsfhiJA8N41LpzPmNzzfDSO32stQ5jNvskoPcwKKwnB_A1cOS97iGZy7jEYTLGkrkq4CMzaSaY0V8Ew47dmKP7POGA"
                alt="Maharashtra State Emblem"
                className="w-16 h-16 object-contain"
                referrerPolicy="no-referrer"
              />
            </div>

            <div>
              <span className="inline-block px-2.5 py-0.5 bg-[#004485]/10 text-[#004485] font-mono font-bold text-[10px] rounded uppercase tracking-wider mb-1">
                State Legal Intelligence Platform
              </span>
              <h1 className="font-poppins text-2xl font-bold text-[#191c1d] tracking-tight">
                MAHA-GR ALIGN
              </h1>
              <p className="text-xs text-[#424751] mt-1 font-medium">
                AI Resolution Alignment &amp; Semantic Conflict Management System
              </p>
            </div>
          </div>

          {/* Form Body */}
          <form onSubmit={handleSubmit} className="p-8 space-y-5">
            {/* Officer ID / Email */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-[#191c1d] uppercase tracking-wider">
                Officer ID / Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-[#727783] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 bg-[#f8f9fa] border border-[#c2c6d3] rounded-lg text-xs text-[#191c1d] focus:bg-white focus:border-[#004485] outline-none font-medium transition-colors"
                  placeholder="e.g. officer@maharashtra.gov.in"
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-[#191c1d] uppercase tracking-wider">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-[#727783] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-10 py-2.5 bg-[#f8f9fa] border border-[#c2c6d3] rounded-lg text-xs text-[#191c1d] focus:bg-white focus:border-[#004485] outline-none font-medium transition-colors"
                  placeholder="Enter your security password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#727783] hover:text-[#191c1d] cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Options Row */}
            <div className="flex justify-between items-center text-xs">
              <label className="flex items-center gap-2 cursor-pointer font-medium text-[#424751]">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="rounded text-[#004485] focus:ring-[#004485]"
                />
                Remember Me
              </label>

              <button
                type="button"
                onClick={() => alert('Please contact the Mantralaya IT Cell Administrator to reset your password.')}
                className="text-[#004485] hover:underline font-bold text-[11px] cursor-pointer"
              >
                Forgot Password?
              </button>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-[#004485] hover:bg-[#0b5cad] text-white font-poppins font-bold py-3 rounded-xl text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
            >
              {isLoading ? (
                <span>Authenticating Officer Credentials...</span>
              ) : (
                <>
                  <span>Sign In to Secure Portal</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            {/* Security Disclaimer */}
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-900 leading-snug flex gap-2">
              <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <span>
                Authorized Government Personnel only. Unauthorized access is strictly monitored under the IT Act 2000.
              </span>
            </div>
          </form>
        </div>
      </main>

      {/* Official Government Footer */}
      <footer className="bg-white border-t border-[#c2c6d3] py-4 px-6 text-center text-xs text-[#424751] space-y-1">
        <p className="font-semibold text-[#191c1d]">
          Government of Maharashtra © {new Date().getFullYear()} • e-Governance &amp; IT Cell, Mantralaya, Mumbai
        </p>
        <p className="text-[11px] text-[#727783]">
          Designed and maintained for Maharashtra State Resolution Integrity &amp; Alignment
        </p>
      </footer>
    </div>
  );
};
